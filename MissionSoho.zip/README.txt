MISSION SOHO — GitHub Actions APK Build Steps
=============================================

1. Create a new empty repository on GitHub (public or private).
2. Upload ALL files from MissionSoho.zip to the repository, keeping the exact folder structure (including the hidden .github/workflows/build.yml and .gitignore files).
3. Open the "Actions" tab in your GitHub repository.
4. Select the "Build Mission Soho APK" workflow and click "Run workflow" (or let the push trigger it automatically).
5. Wait ~2-3 minutes for the build to turn green, open the completed run, and download the "MissionSoho-APK" artifact.
6. Unzip the artifact on your Android 7+ phone and install app-debug.apk (enable "Install unknown apps" if prompted).
