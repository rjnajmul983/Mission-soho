(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var FX = {
    tracers: [],
    sparks: [],
    shells: [],
    explosions: [],
    muzzleLight: null,
    muzzleTimer: 0,
    rainPoints: null,
    rainEnabled: true,
    RAIN_COUNT: 550,

    init: function () {
      var scene = S.Core.scene;

      // Muzzle flash light
      this.muzzleLight = new THREE.PointLight(0xffaa44, 0, 10);
      scene.add(this.muzzleLight);

      // Tracer pool (24)
      var tGeo = new THREE.BoxGeometry(0.03, 0.03, 1.0);
      var tMat = new THREE.MeshBasicMaterial({ color: 0xffe488 });
      for (var i = 0; i < 24; i++) {
        var tm = new THREE.Mesh(tGeo, tMat);
        tm.visible = false;
        scene.add(tm);
        this.tracers.push({ mesh: tm, life: 0 });
      }

      // Spark / blood particle pool (60)
      var pGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
      for (var j = 0; j < 60; j++) {
        var pm = new THREE.Mesh(pGeo, new THREE.MeshBasicMaterial({ color: 0xffcc44 }));
        pm.visible = false;
        scene.add(pm);
        this.sparks.push({ mesh: pm, vx: 0, vy: 0, vz: 0, life: 0 });
      }

      // Shell casing pool (16)
      var sGeo = new THREE.BoxGeometry(0.025, 0.025, 0.07);
      var sMat = new THREE.MeshBasicMaterial({ color: 0xd4a838 });
      for (var k = 0; k < 16; k++) {
        var sm = new THREE.Mesh(sGeo, sMat);
        sm.visible = false;
        scene.add(sm);
        this.shells.push({ mesh: sm, vx: 0, vy: 0, vz: 0, life: 0 });
      }

      // Explosion shockwave pool (4)
      var eGeo = new THREE.SphereGeometry(1, 12, 8);
      for (var e = 0; e < 4; e++) {
        var em = new THREE.Mesh(eGeo, new THREE.MeshBasicMaterial({
          color: 0xff5522, transparent: true, opacity: 0.75, wireframe: false
        }));
        em.visible = false;
        scene.add(em);
        this.explosions.push({ mesh: em, life: 0, maxLife: 0.45 });
      }

      // Neon rain points
      var rGeo = new THREE.BufferGeometry();
      var pos = new Float32Array(this.RAIN_COUNT * 3);
      for (var r = 0; r < this.RAIN_COUNT; r++) {
        pos[r * 3] = (Math.random() - 0.5) * 46;
        pos[r * 3 + 1] = Math.random() * 24;
        pos[r * 3 + 2] = (Math.random() - 0.5) * 46;
      }
      rGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      var rMat = new THREE.PointsMaterial({
        color: 0x66ccff, size: 0.14, transparent: true, opacity: 0.48
      });
      this.rainPoints = new THREE.Points(rGeo, rMat);
      this.rainPoints.frustumCulled = false;
      scene.add(this.rainPoints);
    },

    setRainEnabled: function (on) {
      this.rainEnabled = !!on;
      if (this.rainPoints) this.rainPoints.visible = this.rainEnabled;
    },

    spawnMuzzle: function (pos) {
      this.muzzleLight.position.copy(pos);
      this.muzzleLight.intensity = 3.2;
      this.muzzleTimer = 0.05;
    },

    spawnTracer: function (ax, ay, az, bx, by, bz, color) {
      for (var i = 0; i < this.tracers.length; i++) {
        var t = this.tracers[i];
        if (t.life <= 0) {
          var dx = bx - ax, dy = by - ay, dz = bz - az;
          var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (len < 0.2) return;
          t.mesh.position.set((ax + bx) * 0.5, (ay + by) * 0.5, (az + bz) * 0.5);
          t.mesh.scale.set(1, 1, Math.min(len, 45));
          t.mesh.lookAt(bx, by, bz);
          t.mesh.material.color.setHex(color || 0xffe488);
          t.mesh.visible = true;
          t.life = 0.055;
          return;
        }
      }
    },

    spawnImpact: function (x, y, z, color, count) {
      var n = count || 5;
      var spawned = 0;
      for (var i = 0; i < this.sparks.length && spawned < n; i++) {
        var p = this.sparks[i];
        if (p.life <= 0) {
          p.mesh.position.set(x, y, z);
          p.mesh.material.color.setHex(color || 0xffcc44);
          p.mesh.visible = true;
          p.vx = (Math.random() - 0.5) * 6;
          p.vy = 1.5 + Math.random() * 4;
          p.vz = (Math.random() - 0.5) * 6;
          p.life = 0.28 + Math.random() * 0.2;
          spawned++;
        }
      }
    },

    spawnShell: function (pos, rightDir) {
      for (var i = 0; i < this.shells.length; i++) {
        var s = this.shells[i];
        if (s.life <= 0) {
          s.mesh.position.copy(pos);
          s.mesh.visible = true;
          s.vx = rightDir.x * (1.8 + Math.random()) + (Math.random() - 0.5) * 0.5;
          s.vy = 1.6 + Math.random() * 0.8;
          s.vz = rightDir.z * (1.8 + Math.random()) + (Math.random() - 0.5) * 0.5;
          s.life = 0.7;
          return;
        }
      }
    },

    spawnExplosion: function (x, y, z) {
      this.spawnImpact(x, y + 0.5, z, 0xff6622, 16);
      for (var i = 0; i < this.explosions.length; i++) {
        var e = this.explosions[i];
        if (e.life <= 0) {
          e.mesh.position.set(x, y + 0.4, z);
          e.mesh.scale.set(0.5, 0.5, 0.5);
          e.mesh.material.opacity = 0.8;
          e.mesh.visible = true;
          e.life = e.maxLife;
          return;
        }
      }
    },

    update: function (dt, camPos) {
      if (this.muzzleTimer > 0) {
        this.muzzleTimer -= dt;
        if (this.muzzleTimer <= 0) this.muzzleLight.intensity = 0;
      }

      for (var i = 0; i < this.tracers.length; i++) {
        var t = this.tracers[i];
        if (t.life > 0) {
          t.life -= dt;
          if (t.life <= 0) t.mesh.visible = false;
        }
      }

      for (var j = 0; j < this.sparks.length; j++) {
        var p = this.sparks[j];
        if (p.life > 0) {
          p.life -= dt;
          p.vy -= 14 * dt;
          p.mesh.position.x += p.vx * dt;
          p.mesh.position.y += p.vy * dt;
          p.mesh.position.z += p.vz * dt;
          if (p.life <= 0) p.mesh.visible = false;
        }
      }

      for (var k = 0; k < this.shells.length; k++) {
        var s = this.shells[k];
        if (s.life > 0) {
          s.life -= dt;
          s.vy -= 12 * dt;
          s.mesh.position.x += s.vx * dt;
          s.mesh.position.y = Math.max(0.02, s.mesh.position.y + s.vy * dt);
          s.mesh.position.z += s.vz * dt;
          s.mesh.rotation.x += 12 * dt;
          s.mesh.rotation.z += 9 * dt;
          if (s.life <= 0) s.mesh.visible = false;
        }
      }

      for (var e = 0; e < this.explosions.length; e++) {
        var ex = this.explosions[e];
        if (ex.life > 0) {
          ex.life -= dt;
          var p01 = 1 - Math.max(0, ex.life / ex.maxLife);
          var sc = 0.6 + p01 * 5.8;
          ex.mesh.scale.set(sc, sc, sc);
          ex.mesh.material.opacity = (1 - p01) * 0.75;
          if (ex.life <= 0) ex.mesh.visible = false;
        }
      }

      if (this.rainEnabled && this.rainPoints && camPos) {
        var arr = this.rainPoints.geometry.attributes.position.array;
        for (var r = 0; r < this.RAIN_COUNT; r++) {
          var idx = r * 3;
          arr[idx + 1] -= 22 * dt;
          if (arr[idx + 1] < 0) {
            arr[idx] = camPos.x + (Math.random() - 0.5) * 44;
            arr[idx + 1] = 18 + Math.random() * 8;
            arr[idx + 2] = camPos.z + (Math.random() - 0.5) * 44;
          }
        }
        this.rainPoints.geometry.attributes.position.needsUpdate = true;
      }
    }
  };

  S.FX = FX;
})();
