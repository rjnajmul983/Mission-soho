(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var MAX_POOL = 20;

  var TYPES = {
    grunt:      { name: "GRUNT",      hp: 75,  speed: 3.6, dmg: 8,  fireRate: 0.75, range: 32, color: 0x3366cc, visor: 0x00f0ff, scale: 1.0,  cash: 40,  xp: 50 },
    shotgunner: { name: "SHOTGUNNER", hp: 95,  speed: 4.5, dmg: 14, fireRate: 1.15, range: 16, color: 0xcc4422, visor: 0xffaa00, scale: 1.04, cash: 55,  xp: 65 },
    sniper:     { name: "SNIPER",     hp: 65,  speed: 3.0, dmg: 22, fireRate: 1.9,  range: 52, color: 0x7722aa, visor: 0xff2a85, scale: 0.96, cash: 70,  xp: 80 },
    heavy:      { name: "HEAVY",      hp: 185, speed: 2.5, dmg: 11, fireRate: 0.5,  range: 28, color: 0x224433, visor: 0x00ff88, scale: 1.22, cash: 95,  xp: 110 },
    boss:       { name: "KINGPIN",    hp: 950, speed: 3.4, dmg: 15, fireRate: 0.42, range: 44, color: 0x990033, visor: 0xffde59, scale: 1.48, cash: 500, xp: 500 }
  };

  function buildHumanoidMesh() {
    var root = new THREE.Group();
    var bodyMat = new THREE.MeshStandardMaterial({ color: 0x3366cc, roughness: 0.55 });
    var darkMat = new THREE.MeshStandardMaterial({ color: 0x181a24, roughness: 0.7 });
    var visorMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });

    var torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.72, 0.32), bodyMat);
    torso.position.y = 1.08;
    root.add(torso);

    var head = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.32, 0.32), darkMat);
    head.position.y = 1.62;
    root.add(head);

    var visor = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.09, 0.06), visorMat);
    visor.position.set(0, 1.64, 0.16);
    root.add(visor);

    var legL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.2), darkMat);
    legL.position.set(-0.15, 0.36, 0);
    root.add(legL);
    var legR = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.2), darkMat);
    legR.position.set(0.15, 0.36, 0);
    root.add(legR);

    var armL = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.58, 0.16), bodyMat);
    armL.position.set(-0.37, 1.08, 0.1);
    armL.rotation.x = -0.6;
    root.add(armL);

    var armR = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.58, 0.16), bodyMat);
    armR.position.set(0.37, 1.08, 0.12);
    armR.rotation.x = -0.8;
    root.add(armR);

    var gun = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.55), darkMat);
    gun.position.set(0.32, 1.12, 0.42);
    root.add(gun);

    var hpBg = new THREE.Mesh(
      new THREE.PlaneGeometry(0.75, 0.08),
      new THREE.MeshBasicMaterial({ color: 0x220810, side: THREE.DoubleSide })
    );
    hpBg.position.y = 2.02;
    root.add(hpBg);

    var hpBar = new THREE.Mesh(
      new THREE.PlaneGeometry(0.73, 0.06),
      new THREE.MeshBasicMaterial({ color: 0xff2a55, side: THREE.DoubleSide })
    );
    hpBar.position.set(0, 2.02, 0.01);
    root.add(hpBar);

    return {
      root: root, torso: torso, head: head, visor: visor,
      legL: legL, legR: legR, armR: armR, hpBg: hpBg, hpBar: hpBar,
      bodyMat: bodyMat, visorMat: visorMat
    };
  }

  var Enemies = {
    TYPES: TYPES,
    pool: [],
    activeCount: 0,
    repathCursor: 0,

    init: function () {
      var scene = S.Core.scene;
      for (var i = 0; i < MAX_POOL; i++) {
        var m = buildHumanoidMesh();
        m.root.visible = false;
        scene.add(m.root);
        this.pool.push({
          id: i,
          active: false,
          type: "grunt",
          spec: TYPES.grunt,
          mesh: m,
          x: 0, y: 0, z: 0,
          yaw: 0,
          hp: 75, maxHp: 75,
          state: "IDLE", // IDLE, PATROL, ALERT, CHASE, COVER, ATTACK, FLANK, RETREAT, DEAD
          stateTimer: 0,
          fireTimer: 0,
          reactTimer: 0,
          repathTimer: 0,
          deathTimer: 0,
          animPhase: Math.random() * 6,
          hitFlash: 0,
          path: [],
          pathIdx: 0,
          patrolTarget: null,
          coverTarget: null,
          lastSeenX: 0, lastSeenZ: 0,
          bossPhase: 1
        });
      }
    },

    clearAll: function () {
      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];
        e.active = false;
        e.state = "DEAD";
        e.mesh.root.visible = false;
      }
      this.activeCount = 0;
    },

    spawn: function (type, x, y, z) {
      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];
        if (!e.active && e.deathTimer <= 0) {
          var spec = TYPES[type] || TYPES.grunt;
          var diff = S.Save.data.settings.gameplay.difficulty;
          var hpMul = diff === "easy" ? 0.8 : (diff === "hard" ? 1.25 : 1.0);
          e.active = true;
          e.type = type;
          e.spec = spec;
          e.x = x; e.y = y || 0; e.z = z;
          e.yaw = Math.random() * Math.PI * 2;
          e.maxHp = Math.round(spec.hp * hpMul);
          e.hp = e.maxHp;
          e.state = "PATROL";
          e.stateTimer = 1 + Math.random() * 2;
          e.fireTimer = 0.6;
          e.reactTimer = 0.35 + Math.random() * 0.45;
          e.repathTimer = (i % 5) * 0.1; // staggered re-pathing <= 0.5s
          e.deathTimer = 0;
          e.hitFlash = 0;
          e.path.length = 0;
          e.pathIdx = 0;
          e.patrolTarget = null;
          e.coverTarget = null;
          e.bossPhase = 1;

          e.mesh.bodyMat.color.setHex(spec.color);
          e.mesh.visorMat.color.setHex(spec.visor);
          e.mesh.root.scale.setScalar(spec.scale);
          e.mesh.root.rotation.set(0, e.yaw, 0);
          e.mesh.root.position.set(x, e.y, z);
          e.mesh.hpBar.scale.x = 1;
          e.mesh.hpBg.visible = true;
          e.mesh.hpBar.visible = true;
          e.mesh.root.visible = true;
          this.activeCount++;
          return e;
        }
      }
      return null;
    },

    alertHearing: function (px, pz, radius) {
      var r2 = radius * radius;
      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];
        if (!e.active) continue;
        var dx = px - e.x, dz = pz - e.z;
        if (dx * dx + dz * dz <= r2) {
          e.lastSeenX = px;
          e.lastSeenZ = pz;
          if (e.state === "IDLE" || e.state === "PATROL") {
            e.state = "ALERT";
            e.reactTimer = 0.3 + Math.random() * 0.4;
          }
        }
      }
    },

    // Raycast vs active enemy head & torso hitboxes
    raycast: function (ox, oy, oz, dx, dy, dz, maxDist) {
      var bestDist = maxDist;
      var bestHit = null;

      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];
        if (!e.active) continue;
        var sc = e.spec.scale;
        // Quick sphere reject
        var ex = e.x - ox, ey = (e.y + 1.0 * sc) - oy, ez = e.z - oz;
        var proj = ex * dx + ey * dy + ez * dz;
        if (proj < 0 || proj > bestDist) continue;

        // Head sphere test (headshot x2)
        var hy = e.y + 1.62 * sc;
        var hdx = e.x - ox, hdy = hy - oy, hdz = e.z - oz;
        var hp = hdx * dx + hdy * dy + hdz * dz;
        if (hp > 0 && hp < bestDist) {
          var hx = ox + dx * hp - e.x;
          var hy2 = oy + dy * hp - hy;
          var hz = oz + dz * hp - e.z;
          var hr = 0.25 * sc;
          if (hx * hx + hy2 * hy2 + hz * hz <= hr * hr) {
            bestDist = hp;
            bestHit = { enemy: e, head: true, dist: hp, x: ox + dx * hp, y: oy + dy * hp, z: oz + dz * hp };
            continue;
          }
        }

        // Body cylinder/box test
        var bx = ox + dx * proj - e.x;
        var by = oy + dy * proj - (e.y + 0.92 * sc);
        var bz = oz + dz * proj - e.z;
        var br = 0.44 * sc;
        if (bx * bx + bz * bz <= br * br && Math.abs(by) <= 0.78 * sc) {
          bestDist = proj;
          bestHit = { enemy: e, head: false, dist: proj, x: ox + dx * proj, y: oy + dy * proj, z: oz + dz * proj };
        }
      }
      return bestHit;
    },

    damageEnemy: function (e, dmg, isHead, hx, hy, hz) {
      if (!e.active) return;
      e.hp -= dmg;
      e.hitFlash = 0.12;
      e.mesh.bodyMat.color.setHex(0xffffff);
      e.lastSeenX = S.Player.pos.x;
      e.lastSeenZ = S.Player.pos.z;
      if (e.state === "IDLE" || e.state === "PATROL") e.state = "CHASE";

      if (S.HUD) S.HUD.spawnDamageNumber(hx, hy + 0.35, hz, dmg, isHead);

      // Boss 3-phase transitions
      if (e.type === "boss") {
        var ratio = e.hp / e.maxHp;
        if (e.bossPhase === 1 && ratio < 0.66) {
          e.bossPhase = 2;
          S.HUD.showBanner("KINGPIN PHASE 2 — ENRAGED ASSAULT!");
          S.Missions.onBossPhase(2, e);
        } else if (e.bossPhase === 2 && ratio < 0.33) {
          e.bossPhase = 3;
          S.HUD.showBanner("KINGPIN PHASE 3 — OVERDRIVE!");
          S.Missions.onBossPhase(3, e);
        }
      }

      if (e.hp <= 0) {
        e.active = false;
        e.state = "DEAD";
        e.deathTimer = 2.0;
        e.mesh.hpBg.visible = false;
        e.mesh.hpBar.visible = false;
        this.activeCount = Math.max(0, this.activeCount - 1);
        if (S.HUD) S.HUD.addKillFeed(e.spec.name, isHead);
        if (S.Missions) S.Missions.onEnemyKilled(e, isHead);
      } else {
        var frac = Math.max(0.01, e.hp / e.maxHp);
        e.mesh.hpBar.scale.x = frac;
      }
    },

    explodeAt: function (x, y, z, radius, maxDmg) {
      var r2 = radius * radius;
      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];
        if (!e.active) continue;
        var dx = e.x - x, dy = (e.y + 0.8) - y, dz = e.z - z;
        var d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < r2) {
          var falloff = 1 - Math.sqrt(d2) / radius;
          var dmg = Math.round(maxDmg * (0.35 + 0.65 * falloff));
          this.damageEnemy(e, dmg, false, e.x, e.y + 1.2, e.z);
        }
      }
    },

    fireAtPlayer: function (e, player, dist) {
      var diff = S.Save.data.settings.gameplay.difficulty;
      var baseAcc = diff === "easy" ? 0.35 : (diff === "hard" ? 0.72 : 0.52);
      var distAcc = Math.max(0.18, 1 - dist / (e.spec.range * 1.4));
      var hitChance = baseAcc * distAcc * (player.moving ? 0.75 : 1.0);

      var sx = e.x, sy = e.y + 1.3 * e.spec.scale, sz = e.z;
      var tx = player.pos.x + (Math.random() - 0.5) * 1.2;
      var ty = player.pos.y + 1.1 + (Math.random() - 0.5) * 0.6;
      var tz = player.pos.z + (Math.random() - 0.5) * 1.2;

      S.FX.spawnTracer(sx, sy, sz, tx, ty, tz, e.type === "boss" ? 0xff2a85 : 0xff6644);
      S.Audio.playShot(e.type === "sniper" ? "sniper" : (e.type === "shotgunner" ? "shotgun" : "pistol"));

      if (Math.random() < hitChance) {
        player.takeDamage(e.spec.dmg, e.x, e.z);
      }
    },

    moveAlongPath: function (e, dt, speed) {
      if (e.pathIdx >= e.path.length) return false;
      var wp = e.path[e.pathIdx];
      var dx = wp.x - e.x, dz = wp.z - e.z;
      var d = Math.hypot(dx, dz);
      if (d < 0.75) {
        e.pathIdx++;
        return true;
      }
      var nx = e.x + (dx / d) * speed * dt;
      var nz = e.z + (dz / d) * speed * dt;
      if (!S.Physics.pointBlockedXZ(nx, nz, e.y + 1.0)) {
        e.x = nx; e.z = nz;
      } else {
        e.pathIdx = e.path.length; // force repath
      }
      e.yaw = Math.atan2(dx, dz);
      e.animPhase += dt * speed * 2.6;
      return true;
    },

    update: function (dt, player) {
      var camPos = S.Core.camera.position;

      for (var i = 0; i < this.pool.length; i++) {
        var e = this.pool[i];

        // Death fall animation
        if (!e.active) {
          if (e.deathTimer > 0) {
            e.deathTimer -= dt;
            e.mesh.root.rotation.x = Math.min(Math.PI / 2, e.mesh.root.rotation.x + dt * 5);
            e.mesh.root.position.y = Math.max(e.y + 0.15, e.mesh.root.position.y - dt * 0.4);
            if (e.deathTimer <= 0) e.mesh.root.visible = false;
          }
          continue;
        }

        if (e.hitFlash > 0) {
          e.hitFlash -= dt;
          if (e.hitFlash <= 0) e.mesh.bodyMat.color.setHex(e.spec.color);
        }

        var dxP = player.pos.x - e.x;
        var dzP = player.pos.z - e.z;
        var distP = Math.hypot(dxP, dzP);
        var sees = S.AI.canSeePlayer(e, player);
        if (sees) {
          e.lastSeenX = player.pos.x;
          e.lastSeenZ = player.pos.z;
        }

        e.repathTimer -= dt;
        e.stateTimer -= dt;
        e.fireTimer -= dt;

        var spd = e.spec.speed * (e.type === "boss" && e.bossPhase >= 2 ? 1.35 : 1.0);
        var moved = false;

        // State machine: IDLE / PATROL -> ALERT -> CHASE -> COVER -> ATTACK -> FLANK -> RETREAT
        if (e.state === "IDLE" || e.state === "PATROL") {
          if (sees) {
            e.state = "ALERT";
            e.reactTimer = 0.3 + Math.random() * 0.5;
          } else {
            if (!e.patrolTarget || e.stateTimer <= 0) {
              var ang = Math.random() * Math.PI * 2;
              var px = e.x + Math.cos(ang) * 10;
              var pz = e.z + Math.sin(ang) * 10;
              e.patrolTarget = { x: px, z: pz };
              S.AI.findPath(e.x, e.z, px, pz, e.path);
              e.pathIdx = 0;
              e.stateTimer = 4 + Math.random() * 3;
            }
            moved = this.moveAlongPath(e, dt, spd * 0.55);
          }
        } else if (e.state === "ALERT") {
          e.yaw = Math.atan2(e.lastSeenX - e.x, e.lastSeenZ - e.z);
          e.reactTimer -= dt;
          if (e.reactTimer <= 0) {
            e.state = sees && distP <= e.spec.range ? "ATTACK" : "CHASE";
          }
        } else if (e.state === "CHASE") {
          if (sees && distP <= e.spec.range * 0.85) {
            e.state = (e.hp < e.maxHp * 0.35 && e.type !== "boss") ? "RETREAT" : "ATTACK";
            e.stateTimer = 2.0 + Math.random() * 1.5;
          } else {
            if (e.repathTimer <= 0) {
              e.repathTimer = 0.5;
              S.AI.findPath(e.x, e.z, e.lastSeenX, e.lastSeenZ, e.path);
              e.pathIdx = 0;
            }
            moved = this.moveAlongPath(e, dt, spd);
          }
        } else if (e.state === "ATTACK") {
          e.yaw = Math.atan2(dxP, dzP);
          if (!sees || distP > e.spec.range * 1.1) {
            e.state = "CHASE";
          } else {
            // Strafe slightly while firing
            var strafe = Math.sin(e.animPhase * 0.5) * 1.3 * dt;
            var sx = e.x + Math.cos(e.yaw) * strafe;
            var sz = e.z - Math.sin(e.yaw) * strafe;
            if (!S.Physics.pointBlockedXZ(sx, sz, e.y + 1.0)) {
              e.x = sx; e.z = sz;
            }
            if (e.fireTimer <= 0) {
              var rate = e.spec.fireRate * (e.type === "boss" && e.bossPhase === 3 ? 0.6 : 1.0);
              e.fireTimer = rate;
              this.fireAtPlayer(e, player, distP);
            }
            if (e.stateTimer <= 0) {
              if (e.hp < e.maxHp * 0.4 && e.type !== "boss") {
                e.coverTarget = S.AI.findNearestCover(e.x, e.z, player.pos.x, player.pos.z);
                e.state = e.coverTarget ? "COVER" : "FLANK";
              } else {
                e.state = Math.random() > 0.5 ? "FLANK" : "ATTACK";
              }
              e.stateTimer = 2.2;
            }
          }
        } else if (e.state === "COVER" || e.state === "RETREAT") {
          if (!e.coverTarget) e.coverTarget = S.AI.findNearestCover(e.x, e.z, player.pos.x, player.pos.z);
          if (e.coverTarget) {
            if (e.repathTimer <= 0) {
              e.repathTimer = 0.5;
              S.AI.findPath(e.x, e.z, e.coverTarget.x, e.coverTarget.z, e.path);
              e.pathIdx = 0;
            }
            moved = this.moveAlongPath(e, dt, spd * 1.05);
          }
          if (e.stateTimer <= 0) {
            e.state = sees ? "ATTACK" : "CHASE";
            e.stateTimer = 2.0;
          }
        } else if (e.state === "FLANK") {
          if (e.repathTimer <= 0) {
            e.repathTimer = 0.5;
            var side = (e.id % 2 === 0 ? 1 : -1) * 8;
            var fx = player.pos.x + Math.cos(e.yaw) * side;
            var fz = player.pos.z - Math.sin(e.yaw) * side;
            S.AI.findPath(e.x, e.z, fx, fz, e.path);
            e.pathIdx = 0;
          }
          moved = this.moveAlongPath(e, dt, spd);
          if (e.stateTimer <= 0) {
            e.state = sees ? "ATTACK" : "CHASE";
            e.stateTimer = 2.2;
          }
        }

        // Procedural walk/aim animation
        var swing = moved ? Math.sin(e.animPhase) * 0.55 : 0;
        e.mesh.legL.rotation.x = swing;
        e.mesh.legR.rotation.x = -swing;
        e.mesh.root.position.set(e.x, e.y, e.z);
        e.mesh.root.rotation.set(0, e.yaw, 0);

        // Billboard HP bar toward camera
        e.mesh.hpBg.lookAt(camPos.x, e.y + 2.02, camPos.z);
        e.mesh.hpBar.lookAt(camPos.x, e.y + 2.02, camPos.z);
      }
    }
  };

  S.Enemies = Enemies;
})();
