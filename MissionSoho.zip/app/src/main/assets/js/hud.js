(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var COLORS = { cyan: "#00f0ff", green: "#00ff88", pink: "#ff2a85", white: "#ffffff" };
  var DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];

  var HUD = {
    mmCtx: null,
    hitTimer: 0,
    arcTimers: { n: 0, e: 0, s: 0, w: 0 },
    bannerTimer: 0,
    dmgPool: [],
    kfItems: [],

    init: function () {
      var c = document.getElementById("minimap-canvas");
      if (c) this.mmCtx = c.getContext("2d");

      // Pre-allocate 14 floating damage number DOM nodes
      var container = document.getElementById("dmg-numbers");
      for (var i = 0; i < 14; i++) {
        var el = document.createElement("div");
        el.className = "dmg-num hidden";
        container.appendChild(el);
        this.dmgPool.push({ el: el, wx: 0, wy: 0, wz: 0, life: 0 });
      }
      this.applyCrosshairStyle();
    },

    applyCrosshairStyle: function () {
      var ch = document.getElementById("crosshair");
      if (!ch) return;
      var gp = S.Save.data.settings.gameplay;
      ch.classList.remove("style-dot", "style-circle");
      if (gp.crosshairStyle === "dot") ch.classList.add("style-dot");
      else if (gp.crosshairStyle === "circle") ch.classList.add("style-circle");
      ch.style.setProperty("--ch-color", COLORS[gp.crosshairColor] || "#00f0ff");
    },

    showHitMarker: function (isHead) {
      var hm = document.getElementById("hit-marker");
      if (!hm) return;
      hm.classList.toggle("head", !!isHead);
      hm.style.opacity = "1";
      this.hitTimer = 0.14;
    },

    showDamageArc: function (px, pz, playerYaw, sx, sz) {
      var angToSrc = Math.atan2(sx - px, sz - pz);
      var fwdAng = Math.atan2(-Math.sin(playerYaw), -Math.cos(playerYaw));
      var rel = Math.atan2(Math.sin(angToSrc - fwdAng), Math.cos(angToSrc - fwdAng));
      var key = "n";
      if (Math.abs(rel) < Math.PI * 0.25) key = "n";
      else if (Math.abs(rel) > Math.PI * 0.75) key = "s";
      else if (rel > 0) key = "w";
      else key = "e";
      this.arcTimers[key] = 0.55;
      var el = document.getElementById("dmg-arc-" + key);
      if (el) el.style.opacity = "1";
    },

    spawnDamageNumber: function (wx, wy, wz, amount, isHead) {
      for (var i = 0; i < this.dmgPool.length; i++) {
        var d = this.dmgPool[i];
        if (d.life <= 0) {
          d.wx = wx; d.wy = wy; d.wz = wz;
          d.life = 0.65;
          d.el.textContent = (isHead ? "★ " : "") + amount;
          d.el.classList.toggle("head", !!isHead);
          d.el.classList.remove("hidden");
          return;
        }
      }
    },

    addKillFeed: function (enemyName, isHead) {
      var kf = document.getElementById("kill-feed");
      if (!kf) return;
      var item = document.createElement("div");
      item.className = "kf-item";
      item.textContent = "YOU " + (isHead ? "⌖ " : "▸ ") + enemyName;
      kf.appendChild(item);
      this.kfItems.push({ el: item, life: 3.5 });
      if (this.kfItems.length > 4) {
        var old = this.kfItems.shift();
        if (old.el.parentNode) old.el.parentNode.removeChild(old.el);
      }
    },

    showBanner: function (text) {
      var b = document.getElementById("banner-msg");
      if (!b) return;
      b.textContent = text;
      b.classList.remove("hidden");
      this.bannerTimer = 2.8;
    },

    drawMinimap: function (player) {
      var ctx = this.mmCtx;
      if (!ctx) return;
      var w = 110, h = 110, cx = 55, cy = 55, scale = 1.15;
      ctx.clearRect(0, 0, w, h);

      // Subtle radar rings
      ctx.strokeStyle = "rgba(0,240,255,0.2)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, 24, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, 46, 0, Math.PI * 2); ctx.stroke();

      var cos = Math.cos(player.yaw), sin = Math.sin(player.yaw);
      function toMap(wx, wz) {
        var dx = wx - player.pos.x;
        var dz = wz - player.pos.z;
        var rx = dx * cos - dz * sin;
        var rz = dx * sin + dz * cos;
        return { x: cx + rx * scale, y: cy + rz * scale };
      }

      // Pickups (cyan)
      var pks = S.World.pickups;
      ctx.fillStyle = "#00f0ff";
      for (var p = 0; p < pks.length; p++) {
        if (!pks[p].active) continue;
        var mp = toMap(pks[p].x, pks[p].z);
        if (Math.hypot(mp.x - cx, mp.y - cy) < 50) {
          ctx.fillRect(mp.x - 2, mp.y - 2, 4, 4);
        }
      }

      // Enemies (red/pink)
      var ens = S.Enemies.pool;
      for (var i = 0; i < ens.length; i++) {
        var e = ens[i];
        if (!e.active) continue;
        var me = toMap(e.x, e.z);
        if (Math.hypot(me.x - cx, me.y - cy) < 50) {
          ctx.fillStyle = e.type === "boss" ? "#ffde59" : "#ff2a55";
          ctx.beginPath();
          ctx.arc(me.x, me.y, e.type === "boss" ? 4.5 : 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Waypoint (gold)
      if (S.Missions && S.Missions.waypoint) {
        var wp = S.Missions.waypoint;
        var mw = toMap(wp.x, wp.z);
        var d = Math.hypot(mw.x - cx, mw.y - cy);
        if (d > 48) { mw.x = cx + (mw.x - cx) * (48 / d); mw.y = cy + (mw.y - cy) * (48 / d); }
        ctx.fillStyle = "#ffde59";
        ctx.fillRect(mw.x - 3, mw.y - 3, 6, 6);
      }

      // Player triangle (center pointing up)
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.moveTo(cx, cy - 6);
      ctx.lineTo(cx - 4, cy + 5);
      ctx.lineTo(cx + 4, cy + 5);
      ctx.closePath();
      ctx.fill();
    },

    update: function (dt) {
      var p = S.Player;
      var w = S.Weapons.getCurrent();
      var st = S.Weapons.getCurrentState();

      // HP / Armor / Low-HP vignette
      document.getElementById("hp-fill").style.width = Math.max(0, (p.hp / p.maxHp) * 100) + "%";
      document.getElementById("hp-val").textContent = Math.ceil(p.hp);
      document.getElementById("armor-fill").style.width = Math.max(0, (p.armor / Math.max(1, p.maxArmor)) * 100) + "%";
      document.getElementById("armor-val").textContent = Math.ceil(p.armor);
      document.getElementById("low-hp-vignette").style.opacity = p.hp < 35 ? String((35 - p.hp) / 35) : "0";

      // Weapon & Ammo
      document.getElementById("weapon-name").textContent = w.name;
      document.getElementById("ammo-cur").textContent = st.mag;
      document.getElementById("ammo-res").textContent = st.res;
      document.getElementById("grenade-count").textContent = S.Weapons.grenades;

      var rw = document.getElementById("reload-bar-wrap");
      var rb = document.getElementById("reload-bar");
      if (S.Weapons.reloading) {
        rw.classList.remove("hidden");
        var pct = (1 - S.Weapons.reloadTimer / Math.max(0.01, S.Weapons.reloadTotal)) * 100;
        rb.style.width = Math.max(0, Math.min(100, pct)) + "%";
      } else {
        rw.classList.add("hidden");
      }

      // Dynamic crosshair spread
      var ch = document.getElementById("crosshair");
      var gap = 6 + (w.spread + S.Weapons.spreadBloom) * 280 * (p.moving ? 1.35 : 1) * (1 - S.Weapons.adsAlpha * 0.6);
      ch.style.setProperty("--ch-gap", Math.min(34, gap).toFixed(1) + "px");
      ch.classList.toggle("hidden", w.scope && S.Weapons.adsAlpha > 0.65);

      // Hit marker fade
      if (this.hitTimer > 0) {
        this.hitTimer -= dt;
        if (this.hitTimer <= 0) document.getElementById("hit-marker").style.opacity = "0";
      }

      // Damage direction arcs fade
      var keys = ["n", "e", "s", "w"];
      for (var a = 0; a < 4; a++) {
        var k = keys[a];
        if (this.arcTimers[k] > 0) {
          this.arcTimers[k] -= dt;
          document.getElementById("dmg-arc-" + k).style.opacity = String(Math.max(0, this.arcTimers[k] / 0.55));
        }
      }

      // Banner fade
      if (this.bannerTimer > 0) {
        this.bannerTimer -= dt;
        if (this.bannerTimer <= 0) document.getElementById("banner-msg").classList.add("hidden");
      }

      // Compass
      var deg = Math.round(((-p.yaw * 180 / Math.PI) % 360 + 360) % 360);
      var dirName = DIRS[Math.round(deg / 45) % 8];
      document.getElementById("compass-text").textContent = dirName + " · " + deg + "°";

      // Floating damage numbers projection
      var cam = S.Core.camera;
      var v = S.Core.v5;
      for (var d = 0; d < this.dmgPool.length; d++) {
        var dn = this.dmgPool[d];
        if (dn.life > 0) {
          dn.life -= dt;
          dn.wy += dt * 1.1;
          if (dn.life <= 0) {
            dn.el.classList.add("hidden");
          } else {
            v.set(dn.wx, dn.wy, dn.wz).project(cam);
            if (v.z < 1) {
              dn.el.style.left = ((v.x * 0.5 + 0.5) * S.Core.width) + "px";
              dn.el.style.top = ((-v.y * 0.5 + 0.5) * S.Core.height) + "px";
              dn.el.style.opacity = String(Math.min(1, dn.life * 2));
            } else {
              dn.el.style.opacity = "0";
            }
          }
        }
      }

      // 3D Waypoint projection
      var wpEl = document.getElementById("waypoint-marker");
      if (S.Missions && S.Missions.waypoint && S.Missions.active) {
        var wp = S.Missions.waypoint;
        var dist = Math.round(Math.hypot(wp.x - p.pos.x, wp.z - p.pos.z));
        v.set(wp.x, wp.y, wp.z).project(cam);
        if (v.z < 1) {
          wpEl.classList.remove("hidden");
          var sx = Math.max(24, Math.min(S.Core.width - 24, (v.x * 0.5 + 0.5) * S.Core.width));
          var sy = Math.max(46, Math.min(S.Core.height - 46, (-v.y * 0.5 + 0.5) * S.Core.height));
          wpEl.style.left = sx + "px";
          wpEl.style.top = sy + "px";
          document.getElementById("waypoint-dist").textContent = dist + "m";
        } else {
          wpEl.classList.add("hidden");
        }
      } else {
        wpEl.classList.add("hidden");
      }

      // Kill feed expiry
      for (var kf = this.kfItems.length - 1; kf >= 0; kf--) {
        this.kfItems[kf].life -= dt;
        if (this.kfItems[kf].life <= 0) {
          var rem = this.kfItems.splice(kf, 1)[0];
          if (rem.el.parentNode) rem.el.parentNode.removeChild(rem.el);
        }
      }

      this.drawMinimap(p);
    }
  };

  S.HUD = HUD;
})();
