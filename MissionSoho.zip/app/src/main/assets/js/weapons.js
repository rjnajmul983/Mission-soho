(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  // Single centralized weapon table (Section 5 exact specs)
  var WEAPON_TABLE = {
    pistol:  { id: "pistol",  name: "9MM PISTOL",    short: "PISTOL",  dmg: 22, pellets: 1, rpm: 400, mag: 15, res: 90,  reload: 1.4, shellReload: false, spread: 0.014, recoilY: 0.016, recoilX: 0.004, range: 65,  auto: false, scope: false, color: 0x99aacc },
    smg:     { id: "smg",     name: "NEON SMG",      short: "SMG",     dmg: 16, pellets: 1, rpm: 800, mag: 30, res: 180, reload: 1.7, shellReload: false, spread: 0.024, recoilY: 0.013, recoilX: 0.008, range: 55,  auto: true,  scope: false, color: 0x00d8ff },
    rifle:   { id: "rifle",   name: "ASSAULT RIFLE", short: "RIFLE",   dmg: 28, pellets: 1, rpm: 600, mag: 30, res: 150, reload: 2.0, shellReload: false, spread: 0.016, recoilY: 0.020, recoilX: 0.006, range: 90,  auto: true,  scope: false, color: 0x334466 },
    shotgun: { id: "shotgun", name: "BREACH SHOTGUN",short: "SHOTGN",  dmg: 9,  pellets: 8, rpm: 70,  mag: 6,  res: 36,  reload: 0.48,shellReload: true,  spread: 0.068, recoilY: 0.055, recoilX: 0.012, range: 32,  auto: false, scope: false, color: 0x663344 },
    sniper:  { id: "sniper",  name: "RAIL SNIPER",   short: "SNIPER",  dmg: 95, pellets: 1, rpm: 45,  mag: 5,  res: 25,  reload: 2.4, shellReload: false, spread: 0.003, recoilY: 0.065, recoilX: 0.005, range: 150, auto: false, scope: true,  color: 0xff2a85 }
  };

  var FRAG_SPEC = { dmg: 120, radius: 6.0, fuse: 2.5, startCount: 3 };

  var Weapons = {
    TABLE: WEAPON_TABLE,
    FRAG: FRAG_SPEC,
    loadout: ["rifle", "smg", "pistol"],
    allOrder: ["rifle", "smg", "shotgun", "sniper", "pistol"],
    slotIdx: 0,
    state: {},
    grenades: 3,
    activeFrags: [],
    fireCooldown: 0,
    reloading: false,
    reloadTimer: 0,
    reloadTotal: 1,
    switchTimer: 0,
    shotsInBurst: 0,
    spreadBloom: 0,
    adsAlpha: 0,
    scopeZoom: 4, // 4 or 8
    viewGroup: null,
    viewMeshes: {},
    bobPhase: 0,
    recoilKickZ: 0,
    arcLine: null,
    arcPositions: null,
    _hitOut: { hit: false, dist: 0, x: 0, y: 0, z: 0 },

    init: function () {
      this.viewGroup = new THREE.Group();
      S.Core.camera.add(this.viewGroup);
      this.buildViewModels();

      // Grenade trajectory arc preview line
      var arcGeo = new THREE.BufferGeometry();
      this.arcPositions = new Float32Array(24 * 3);
      arcGeo.setAttribute("position", new THREE.BufferAttribute(this.arcPositions, 3));
      this.arcLine = new THREE.Line(arcGeo, new THREE.LineBasicMaterial({ color: 0xffde59 }));
      this.arcLine.visible = false;
      this.arcLine.frustumCulled = false;
      S.Core.scene.add(this.arcLine);

      this.resetLoadout(false);
    },

    buildViewModels: function () {
      var ids = ["pistol", "smg", "rifle", "shotgun", "sniper"];
      for (var i = 0; i < ids.length; i++) {
        var id = ids[i];
        var spec = WEAPON_TABLE[id];
        var g = new THREE.Group();
        var bodyMat = new THREE.MeshStandardMaterial({ color: 0x1e2230, roughness: 0.4, metalness: 0.7 });
        var accentMat = new THREE.MeshBasicMaterial({ color: spec.color });

        var len = id === "pistol" ? 0.28 : (id === "smg" ? 0.42 : (id === "sniper" ? 0.82 : 0.62));
        var body = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.11, len), bodyMat);
        body.position.set(0, 0, -len * 0.4);
        g.add(body);

        var barrel = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, len * 0.65), bodyMat);
        barrel.position.set(0, 0.03, -len * 0.85);
        g.add(barrel);

        var strip = new THREE.Mesh(new THREE.BoxGeometry(0.084, 0.018, len * 0.7), accentMat);
        strip.position.set(0, 0.04, -len * 0.38);
        g.add(strip);

        if (id === "sniper") {
          var scope = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.028, 0.24, 8), bodyMat);
          scope.rotation.x = Math.PI / 2;
          scope.position.set(0, 0.095, -0.22);
          g.add(scope);
        }
        g.visible = false;
        this.viewGroup.add(g);
        this.viewMeshes[id] = g;
      }
    },

    resetLoadout: function (isTraining) {
      var up = S.Save.data.progress.upgrades;
      var magMul = 1 + up.mag * 0.15;
      this.loadout = isTraining ? ["rifle", "shotgun", "sniper"] : ["rifle", "smg", "pistol"];
      this.state = {};
      var keys = Object.keys(WEAPON_TABLE);
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        var w = WEAPON_TABLE[k];
        var m = Math.round(w.mag * magMul);
        this.state[k] = { mag: m, maxMag: m, res: w.res * (isTraining ? 4 : 1) };
      }
      this.grenades = FRAG_SPEC.startCount;
      this.slotIdx = 0;
      this.reloading = false;
      this.fireCooldown = 0;
      this.switchTimer = 0;
      this.spreadBloom = 0;
      this.shotsInBurst = 0;
      this.scopeZoom = 4;
      this.clearFrags();
      this.updateSlotLabels();
      this.showActiveModel();
    },

    clearFrags: function () {
      for (var i = 0; i < this.activeFrags.length; i++) {
        S.Core.scene.remove(this.activeFrags[i].mesh);
      }
      this.activeFrags.length = 0;
    },

    getCurrent: function () {
      return WEAPON_TABLE[this.loadout[this.slotIdx]];
    },

    getCurrentState: function () {
      return this.state[this.loadout[this.slotIdx]];
    },

    showActiveModel: function () {
      var cur = this.loadout[this.slotIdx];
      var keys = Object.keys(this.viewMeshes);
      for (var i = 0; i < keys.length; i++) {
        this.viewMeshes[keys[i]].visible = (keys[i] === cur);
      }
    },

    updateSlotLabels: function () {
      for (var i = 0; i < 3; i++) {
        var el = document.getElementById("slot-" + i);
        if (!el) continue;
        var w = WEAPON_TABLE[this.loadout[i]];
        el.innerHTML = (i + 1) + "<small>" + w.short + "</small>";
        el.classList.toggle("active", i === this.slotIdx);
      }
    },

    selectSlot: function (idx) {
      idx = ((idx % 3) + 3) % 3;
      if (idx === this.slotIdx) return;
      this.slotIdx = idx;
      this.reloading = false;
      this.switchTimer = 0.25;
      this.shotsInBurst = 0;
      if (S.Input) S.Input.adsActive = false;
      this.updateSlotLabels();
      this.showActiveModel();
      S.Audio.playClick();
    },

    cycleWeapon: function (dir) {
      if (S.Missions && S.Missions.mode === "training") {
        // In training range, allow cycling all 5 firearms into current slot
        var curId = this.loadout[this.slotIdx];
        var i = this.allOrder.indexOf(curId);
        var nextId = this.allOrder[(i + dir + this.allOrder.length) % this.allOrder.length];
        this.loadout[this.slotIdx] = nextId;
        this.reloading = false;
        this.switchTimer = 0.2;
        this.updateSlotLabels();
        this.showActiveModel();
        S.Audio.playClick();
      } else {
        this.selectSlot(this.slotIdx + dir);
      }
    },

    equipWeaponId: function (id) {
      if (!WEAPON_TABLE[id]) return;
      this.loadout[0] = id;
      this.slotIdx = 0;
      this.reloading = false;
      this.updateSlotLabels();
      this.showActiveModel();
    },

    startReload: function () {
      if (this.reloading || this.switchTimer > 0) return;
      var w = this.getCurrent();
      var st = this.getCurrentState();
      if (st.mag >= st.maxMag || st.res <= 0) return;
      var up = S.Save.data.progress.upgrades;
      var speedMul = Math.max(0.55, 1 - up.reload * 0.08);
      this.reloading = true;
      this.reloadTotal = w.reload * speedMul;
      this.reloadTimer = this.reloadTotal;
      S.Audio.playReload();
    },

    toggleScopeZoom: function () {
      this.scopeZoom = this.scopeZoom === 4 ? 8 : 4;
      var lbl = document.getElementById("scope-zoom-label");
      var btn = document.getElementById("btn-scope-zoom");
      if (lbl) lbl.textContent = this.scopeZoom + "X";
      if (btn) btn.textContent = this.scopeZoom + "X";
      S.Audio.playClick();
    },

    tryFire: function (player, isAds) {
      if (this.fireCooldown > 0 || this.switchTimer > 0) return;
      var w = this.getCurrent();
      var st = this.getCurrentState();

      // Shell-by-shell shotgun reload can be interrupted to shoot
      if (this.reloading) {
        if (w.shellReload && st.mag > 0) {
          this.reloading = false;
        } else {
          return;
        }
      }

      if (st.mag <= 0) {
        S.Audio.playEmpty();
        this.fireCooldown = 0.25;
        if (S.Save.data.settings.gameplay.autoReload) this.startReload();
        return;
      }

      st.mag--;
      this.fireCooldown = 60 / w.rpm;
      this.shotsInBurst++;
      this.recoilKickZ = 0.06;

      S.Audio.playShot(w.id);
      S.Save.vibrate(w.id === "sniper" || w.id === "shotgun" ? 28 : 14);

      // Muzzle & shell FX
      var cam = S.Core.camera;
      var fwd = S.Core.v1.set(0, 0, -1).applyQuaternion(cam.quaternion).normalize();
      var right = S.Core.v2.set(1, 0, 0).applyQuaternion(cam.quaternion).normalize();
      var muzzlePos = S.Core.v3.copy(cam.position).addScaledVector(fwd, 0.7).addScaledVector(right, 0.18);
      muzzlePos.y -= 0.12;
      S.FX.spawnMuzzle(muzzlePos);
      S.FX.spawnShell(muzzlePos, right);

      // Alert nearby enemies within 60 m (gunshot hearing)
      if (S.Enemies) S.Enemies.alertHearing(player.pos.x, player.pos.z, 60);

      // Compute dynamic spread
      var spread = w.spread + this.spreadBloom;
      if (player.moving) spread *= 1.45;
      if (player.crouched) spread *= 0.65;
      if (isAds) spread *= w.scope ? 0.08 : 0.38;

      var upDmg = 1 + S.Save.data.progress.upgrades.damage * 0.12;
      var hitHead = false;
      var hitBody = false;

      for (var p = 0; p < w.pellets; p++) {
        var dir = S.Core.v4.copy(fwd);
        dir.x += (Math.random() - 0.5) * spread * 2;
        dir.y += (Math.random() - 0.5) * spread * 2;
        dir.z += (Math.random() - 0.5) * spread * 2;
        dir.normalize();

        // 1. Raycast vs world AABBs first (bullets NEVER pass through walls)
        var wallDist = S.Physics.raycastWorld(
          cam.position.x, cam.position.y, cam.position.z,
          dir.x, dir.y, dir.z, w.range, this._hitOut
        );

        // 2. Raycast vs Enemies (only accept hit closer than wallDist)
        var enemyHit = S.Enemies ? S.Enemies.raycast(
          cam.position.x, cam.position.y, cam.position.z,
          dir.x, dir.y, dir.z, wallDist
        ) : null;

        if (enemyHit) {
          var dmg = Math.round(w.dmg * upDmg * (enemyHit.head ? 2.0 : 1.0));
          S.Enemies.damageEnemy(enemyHit.enemy, dmg, enemyHit.head, enemyHit.x, enemyHit.y, enemyHit.z);
          S.FX.spawnTracer(muzzlePos.x, muzzlePos.y, muzzlePos.z, enemyHit.x, enemyHit.y, enemyHit.z, enemyHit.head ? 0xff2a55 : 0xffe488);
          S.FX.spawnImpact(enemyHit.x, enemyHit.y, enemyHit.z, 0xff2a55, 5);
          if (enemyHit.head) hitHead = true; else hitBody = true;
        } else {
          // Check training targets if in training mode
          var hitTgt = this.checkTrainingHit(cam.position, dir, wallDist, Math.round(w.dmg * upDmg));
          if (hitTgt) {
            hitBody = true;
            S.FX.spawnTracer(muzzlePos.x, muzzlePos.y, muzzlePos.z, hitTgt.x, hitTgt.y, hitTgt.z, 0x00f0ff);
            S.FX.spawnImpact(hitTgt.x, hitTgt.y, hitTgt.z, 0x00f0ff, 6);
          } else {
            S.FX.spawnTracer(muzzlePos.x, muzzlePos.y, muzzlePos.z, this._hitOut.x, this._hitOut.y, this._hitOut.z, 0xffe488);
            if (this._hitOut.hit) {
              S.FX.spawnImpact(this._hitOut.x, this._hitOut.y, this._hitOut.z, 0xffcc44, 4);
            }
          }
        }
      }

      if (hitHead || hitBody) {
        S.Audio.playHit(hitHead);
        if (S.HUD) S.HUD.showHitMarker(hitHead);
      }

      // Pattern recoil (Assault Rifle climbs up then pulls slightly right)
      var recY = w.recoilY * (isAds ? 0.65 : 1.0);
      var recX = w.id === "rifle"
        ? (this.shotsInBurst > 4 ? -w.recoilX : (Math.random() - 0.5) * w.recoilX * 0.6)
        : (Math.random() - 0.5) * w.recoilX * 2;
      player.applyRecoil(recX, recY);
      this.spreadBloom = Math.min(0.06, this.spreadBloom + 0.008);

      if (st.mag === 0 && S.Save.data.settings.gameplay.autoReload) {
        this.startReload();
      }
    },

    checkTrainingHit: function (orig, dir, maxDist, dmg) {
      var list = S.World.trainingTargets;
      if (!list || !list.length) return null;
      for (var i = 0; i < list.length; i++) {
        var tg = list[i];
        if (tg.respawn > 0) continue;
        var tx = tg.mesh.position.x - orig.x;
        var ty = tg.mesh.position.y - orig.y;
        var tz = tg.mesh.position.z - orig.z;
        var proj = tx * dir.x + ty * dir.y + tz * dir.z;
        if (proj < 0 || proj > maxDist) continue;
        var cx = orig.x + dir.x * proj - tg.mesh.position.x;
        var cy = orig.y + dir.y * proj - tg.mesh.position.y;
        var cz = orig.z + dir.z * proj - tg.mesh.position.z;
        if (cx * cx + cz * cz < 0.36 && Math.abs(cy) < 0.85) {
          tg.hp -= dmg;
          if (S.HUD) S.HUD.spawnDamageNumber(tg.mesh.position.x, tg.mesh.position.y + 0.6, tg.mesh.position.z, dmg, false);
          if (tg.hp <= 0) {
            tg.respawn = 3.0;
            tg.mesh.visible = false;
            S.Missions.onTrainingTargetHit();
          }
          return { x: orig.x + dir.x * proj, y: orig.y + dir.y * proj, z: orig.z + dir.z * proj };
        }
      }
      return null;
    },

    updateGrenadePreview: function (show) {
      if (!show || this.grenades <= 0) {
        this.arcLine.visible = false;
        return;
      }
      this.arcLine.visible = true;
      var cam = S.Core.camera;
      var fwd = S.Core.v1.set(0, 0, -1).applyQuaternion(cam.quaternion).normalize();
      var vx = fwd.x * 16, vy = fwd.y * 16 + 4.5, vz = fwd.z * 16;
      var px = cam.position.x, py = cam.position.y - 0.15, pz = cam.position.z;
      var arr = this.arcPositions;
      for (var i = 0; i < 24; i++) {
        var t = i * 0.08;
        arr[i * 3] = px + vx * t;
        arr[i * 3 + 1] = Math.max(0.05, py + vy * t - 0.5 * 14 * t * t);
        arr[i * 3 + 2] = pz + vz * t;
      }
      this.arcLine.geometry.attributes.position.needsUpdate = true;
    },

    throwGrenade: function () {
      this.arcLine.visible = false;
      if (this.grenades <= 0) return;
      this.grenades--;
      var cam = S.Core.camera;
      var fwd = S.Core.v1.set(0, 0, -1).applyQuaternion(cam.quaternion).normalize();
      var mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 8, 6),
        new THREE.MeshBasicMaterial({ color: 0xff5522 })
      );
      mesh.position.copy(cam.position).addScaledVector(fwd, 0.6);
      S.Core.scene.add(mesh);
      this.activeFrags.push({
        mesh: mesh,
        vx: fwd.x * 16, vy: fwd.y * 16 + 4.5, vz: fwd.z * 16,
        fuse: FRAG_SPEC.fuse
      });
      S.Audio.playClick();
    },

    update: function (dt, player, input) {
      if (this.fireCooldown > 0) this.fireCooldown -= dt;
      if (this.switchTimer > 0) this.switchTimer -= dt;
      this.spreadBloom = Math.max(0, this.spreadBloom - dt * 0.09);
      this.recoilKickZ = Math.max(0, this.recoilKickZ - dt * 0.35);

      // Reload tick
      if (this.reloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          var w = this.getCurrent();
          var st = this.getCurrentState();
          if (w.shellReload) {
            if (st.mag < st.maxMag && st.res > 0) {
              st.mag++; st.res--;
              S.Audio.playReload();
            }
            if (st.mag < st.maxMag && st.res > 0) {
              this.reloadTimer = this.reloadTotal;
            } else {
              this.reloading = false;
            }
          } else {
            var need = st.maxMag - st.mag;
            var take = Math.min(need, st.res);
            st.mag += take;
            st.res -= take;
            this.reloading = false;
          }
        }
      }

      // Firing logic (Hold / Toggle / Auto-fire on aim)
      var wantFire = input.firing;
      var fm = S.Save.data.settings.controls.fireMode;
      if (fm === "auto" && !wantFire && S.Enemies) {
        var cam = S.Core.camera;
        var fwd = S.Core.v1.set(0, 0, -1).applyQuaternion(cam.quaternion).normalize();
        var wd = S.Physics.raycastWorld(cam.position.x, cam.position.y, cam.position.z, fwd.x, fwd.y, fwd.z, 70);
        if (S.Enemies.raycast(cam.position.x, cam.position.y, cam.position.z, fwd.x, fwd.y, fwd.z, wd)) {
          wantFire = true;
        }
      }
      var curW = this.getCurrent();
      if (wantFire) {
        if (curW.auto || input.fireJustPressed || fm === "auto") {
          this.tryFire(player, input.adsActive);
        }
      } else {
        this.shotsInBurst = 0;
      }

      // ADS & Sniper Scope FOV transition
      var targetAds = input.adsActive && !this.reloading ? 1 : 0;
      this.adsAlpha += (targetAds - this.adsAlpha) * Math.min(1, dt * 12);
      var baseFov = S.Save.data.settings.graphics.fov;
      var targetFov = baseFov;
      var scoped = curW.scope && this.adsAlpha > 0.65;
      if (this.adsAlpha > 0.01) {
        var zoomFov = curW.scope ? (this.scopeZoom === 8 ? 14 : 24) : baseFov * 0.72;
        targetFov = baseFov + (zoomFov - baseFov) * this.adsAlpha;
      }
      if (Math.abs(S.Core.camera.fov - targetFov) > 0.1) {
        S.Core.camera.fov = targetFov;
        S.Core.camera.updateProjectionMatrix();
      }

      // Scope UI visibility
      var scOv = document.getElementById("scope-overlay");
      var zBtn = document.getElementById("btn-scope-zoom");
      if (scOv) scOv.classList.toggle("hidden", !scoped);
      if (zBtn) zBtn.classList.toggle("hidden", !(curW.scope && input.adsActive));
      this.viewGroup.visible = !scoped;

      // Viewmodel sway, bob, ADS centering, reload tilt
      if (player.moving && player.grounded) this.bobPhase += dt * (player.sprinting ? 13 : 9);
      var bobX = Math.cos(this.bobPhase) * 0.012 * (1 - this.adsAlpha * 0.8);
      var bobY = Math.abs(Math.sin(this.bobPhase)) * 0.012 * (1 - this.adsAlpha * 0.8);
      var hipX = 0.22, hipY = -0.21, hipZ = -0.34;
      var adsX = 0.0,  adsY = -0.13, adsZ = -0.26;
      this.viewGroup.position.set(
        hipX + (adsX - hipX) * this.adsAlpha + bobX,
        hipY + (adsY - hipY) * this.adsAlpha - bobY - (this.switchTimer > 0 ? this.switchTimer * 0.8 : 0),
        hipZ + (adsZ - hipZ) * this.adsAlpha + this.recoilKickZ
      );
      this.viewGroup.rotation.set(
        this.reloading ? -0.45 : (this.recoilKickZ * 2.2),
        this.reloading ? 0.35 : 0,
        0
      );

      // Update active thrown grenades
      for (var i = this.activeFrags.length - 1; i >= 0; i--) {
        var f = this.activeFrags[i];
        f.fuse -= dt;
        f.vy -= 14 * dt;
        var nx = f.mesh.position.x + f.vx * dt;
        var ny = f.mesh.position.y + f.vy * dt;
        var nz = f.mesh.position.z + f.vz * dt;
        if (ny < 0.14) {
          ny = 0.14;
          f.vy = Math.abs(f.vy) * 0.38;
          f.vx *= 0.65; f.vz *= 0.65;
        }
        if (S.Physics.pointBlockedXZ(nx, nz, ny)) {
          f.vx *= -0.4; f.vz *= -0.4;
        } else {
          f.mesh.position.set(nx, ny, nz);
        }
        if (f.fuse <= 0) {
          var ex = f.mesh.position.x, ey = f.mesh.position.y, ez = f.mesh.position.z;
          S.Core.scene.remove(f.mesh);
          this.activeFrags.splice(i, 1);
          S.FX.spawnExplosion(ex, ey, ez);
          S.Audio.playExplosion();
          S.Save.vibrate(80);
          if (S.Enemies) S.Enemies.explodeAt(ex, ey, ez, FRAG_SPEC.radius, FRAG_SPEC.dmg);
        }
      }
    }
  };

  S.Weapons = Weapons;
})();
