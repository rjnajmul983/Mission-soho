(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var Core = {
    state: "BOOT", // BOOT, MENU, LOADING, PLAY, PAUSE, RESULT
    renderer: null,
    scene: null,
    camera: null,
    sunLight: null,
    hemiLight: null,
    canvas: null,
    width: window.innerWidth,
    height: window.innerHeight,
    FIXED_DT: 1 / 60,
    MAX_DT: 0.05,
    fps: 60,
    fpsFrames: 0,
    fpsTimer: 0,
    perfMeasureTime: 0,
    perfSamples: 0,
    perfSum: 0,
    perfSuggested: false,

    // Pre-allocated scratch objects (zero allocations in frame loop)
    v1: null, v2: null, v3: null, v4: null, v5: null, v6: null,
    q1: null, q2: null,
    ray: null,

    init: function () {
      if (typeof THREE === "undefined") {
        throw new Error("THREE.js r128 not loaded (assets/js/three.min.js missing)");
      }
      this.v1 = new THREE.Vector3();
      this.v2 = new THREE.Vector3();
      this.v3 = new THREE.Vector3();
      this.v4 = new THREE.Vector3();
      this.v5 = new THREE.Vector3();
      this.v6 = new THREE.Vector3();
      this.q1 = new THREE.Quaternion();
      this.q2 = new THREE.Quaternion();
      this.ray = new THREE.Raycaster();

      this.canvas = document.getElementById("game-canvas");
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: false,
        powerPreference: "high-performance",
        alpha: false
      });
      // THREE r128 rule: use outputEncoding = THREE.sRGBEncoding
      this.renderer.outputEncoding = THREE.sRGBEncoding;
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0x070512);
      this.scene.fog = new THREE.Fog(0x0a071a, 14, 70);

      this.camera = new THREE.PerspectiveCamera(75, this.width / Math.max(1, this.height), 0.1, 140);
      this.camera.rotation.order = "YXZ";
      this.scene.add(this.camera);

      // Lighting
      this.hemiLight = new THREE.HemisphereLight(0x5068a8, 0x160c24, 0.72);
      this.scene.add(this.hemiLight);

      this.sunLight = new THREE.DirectionalLight(0x90b8ff, 0.75);
      this.sunLight.position.set(35, 60, 25);
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(512, 512);
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 150;
      this.sunLight.shadow.camera.left = -45;
      this.sunLight.shadow.camera.right = 45;
      this.sunLight.shadow.camera.top = 45;
      this.sunLight.shadow.camera.bottom = -45;
      this.scene.add(this.sunLight);

      var self = this;
      window.addEventListener("resize", function () { self.onResize(); });
      this.applyGraphics();
      this.onResize();
    },

    applyGraphics: function () {
      var g = S.Save.data.settings.graphics;
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var scale = g.tier === "low" ? 0.6 : (g.tier === "high" ? 1.0 : 0.8);
      var fogFar = g.tier === "low" ? 40 : (g.tier === "high" ? 100 : 70);

      this.renderer.setPixelRatio(Math.max(0.5, dpr * scale));
      this.renderer.setSize(this.width, this.height, false);
      this.scene.fog.far = fogFar;
      this.camera.far = fogFar + 30;
      this.camera.fov = g.fov;
      this.camera.updateProjectionMatrix();

      if (g.tier === "low") {
        this.renderer.shadowMap.enabled = false;
        this.sunLight.castShadow = false;
      } else {
        var sz = g.tier === "high" ? 1024 : 512;
        this.renderer.shadowMap.enabled = true;
        this.sunLight.castShadow = true;
        if (this.sunLight.shadow.mapSize.x !== sz) {
          this.sunLight.shadow.mapSize.set(sz, sz);
          if (this.sunLight.shadow.map) {
            this.sunLight.shadow.map.dispose();
            this.sunLight.shadow.map = null;
          }
        }
      }

      if (S.FX && S.FX.setRainEnabled) {
        S.FX.setRainEnabled(g.rain && g.tier !== "low");
      }
      var fpsEl = document.getElementById("fps-counter");
      if (fpsEl) fpsEl.classList.toggle("hidden", !g.showFps);
    },

    onResize: function () {
      this.width = window.innerWidth || 1;
      this.height = window.innerHeight || 1;
      if (this.camera) {
        this.camera.aspect = this.width / this.height;
        this.camera.updateProjectionMatrix();
      }
      if (this.renderer) {
        this.renderer.setSize(this.width, this.height, false);
      }
      if (S.Input && S.Input.applyLayout) S.Input.applyLayout();
    },

    trackFps: function (dt) {
      this.fpsFrames++;
      this.fpsTimer += dt;
      if (this.fpsTimer >= 0.5) {
        this.fps = Math.round(this.fpsFrames / this.fpsTimer);
        this.fpsFrames = 0;
        this.fpsTimer = 0;
        var el = document.getElementById("fps-counter");
        if (el && !el.classList.contains("hidden")) {
          el.textContent = this.fps + " FPS";
        }
      }
      // Auto-suggest graphics downgrade after 3s of gameplay
      if (this.state === "PLAY" && !this.perfSuggested) {
        this.perfMeasureTime += dt;
        if (dt > 0.001) {
          this.perfSum += 1 / dt;
          this.perfSamples++;
        }
        if (this.perfMeasureTime >= 3.0) {
          this.perfSuggested = true;
          var avg = this.perfSamples > 0 ? this.perfSum / this.perfSamples : 60;
          var tier = S.Save.data.settings.graphics.tier;
          if (avg < 26 && tier !== "low") {
            var nextTier = tier === "high" ? "med" : "low";
            var box = document.getElementById("fps-suggest-box");
            var txt = document.getElementById("fps-suggest-text");
            if (box && txt) {
              txt.textContent = "Avg " + Math.round(avg) + " FPS. Switch to " + nextTier.toUpperCase() + " graphics?";
              box.dataset.suggestTier = nextTier;
              box.classList.remove("hidden");
            }
          }
        }
      }
    },

    setState: function (newState) {
      this.state = newState;
      if (newState === "PLAY") {
        this.perfMeasureTime = 0;
        this.perfSamples = 0;
        this.perfSum = 0;
      }
    }
  };

  S.Core = Core;

  // Android lifecycle hooks required by MainActivity.kt
  S.onAndroidBack = function () {
    if (S.UI && S.UI.handleBack) S.UI.handleBack();
  };
  S.onAndroidPause = function () {
    if (S.Input && S.Input.releaseAll) S.Input.releaseAll();
    if (S.Audio && S.Audio.suspend) S.Audio.suspend();
    if (Core.state === "PLAY" && S.UI && S.UI.pauseGame) {
      S.UI.pauseGame();
    }
  };
  S.onAndroidResume = function () {
    if (S.Audio && S.Audio.resume) S.Audio.resume();
  };
})();
