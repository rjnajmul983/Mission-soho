(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  function makeCanvasTex(w, h, drawFn) {
    var c = document.createElement("canvas");
    c.width = w; c.height = h;
    var ctx = c.getContext("2d");
    drawFn(ctx, w, h);
    var tex = new THREE.CanvasTexture(c);
    tex.encoding = THREE.sRGBEncoding;
    return tex;
  }

  var World = {
    group: null,
    enemySpawns: [],
    playerSpawns: [],
    pickups: [],
    flickerLights: [],
    trainingTargets: [],
    coverPoints: [],
    clubCenter: { x: 39, y: 0, z: -19 },
    plazaCenter: { x: 0, y: 0, z: -20 },
    flickerTime: 0,
    built: false,

    init: function () {
      if (this.built) return;
      this.built = true;
      var scene = S.Core.scene;
      this.group = new THREE.Group();
      scene.add(this.group);
      S.Physics.clear();

      this.createTextures();
      this.buildGround();
      this.buildDistrict();
      this.buildSpawnsAndPickups();
    },

    createTextures: function () {
      // Wet road asphalt
      this.texRoad = makeCanvasTex(256, 256, function (ctx, w, h) {
        ctx.fillStyle = "#12131c";
        ctx.fillRect(0, 0, w, h);
        for (var i = 0; i < 600; i++) {
          ctx.fillStyle = Math.random() > 0.5 ? "rgba(40,55,90,0.22)" : "rgba(0,0,0,0.25)";
          ctx.fillRect(Math.random() * w, Math.random() * h, 6, 3);
        }
        ctx.fillStyle = "rgba(0,240,255,0.12)";
        ctx.fillRect(0, 0, w, 4);
        ctx.fillStyle = "#d8b430";
        ctx.fillRect(w * 0.48, 0, 8, h * 0.45);
      });
      this.texRoad.wrapS = this.texRoad.wrapT = THREE.RepeatWrapping;
      this.texRoad.repeat.set(16, 16);

      // Cyberpunk building facade
      this.texBldg = makeCanvasTex(256, 256, function (ctx, w, h) {
        ctx.fillStyle = "#161426";
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = "#26223e";
        ctx.lineWidth = 2;
        for (var y = 8; y < h; y += 24) {
          for (var x = 8; x < w; x += 28) {
            var r = Math.random();
            if (r > 0.62) ctx.fillStyle = r > 0.85 ? "#00d8ff" : (r > 0.74 ? "#ff3888" : "#ffe088");
            else ctx.fillStyle = "#0c0a18";
            ctx.fillRect(x, y, 18, 14);
            ctx.strokeRect(x, y, 18, 14);
          }
        }
      });
      this.texBldg.wrapS = this.texBldg.wrapT = THREE.RepeatWrapping;

      // Cover crate / barrier
      this.texCover = makeCanvasTex(128, 128, function (ctx, w, h) {
        ctx.fillStyle = "#25293c";
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = "#3f4968";
        ctx.lineWidth = 6;
        ctx.strokeRect(4, 4, w - 8, h - 8);
        ctx.fillStyle = "#e6a820";
        for (var i = -w; i < w * 2; i += 28) {
          ctx.beginPath();
          ctx.moveTo(i, h - 18); ctx.lineTo(i + 14, h - 18);
          ctx.lineTo(i + 6, h); ctx.lineTo(i - 8, h);
          ctx.fill();
        }
      });

      // Radial glow sprite (fake bloom)
      this.texGlow = makeCanvasTex(64, 64, function (ctx, w, h) {
        var g = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
        g.addColorStop(0, "rgba(255,255,255,0.95)");
        g.addColorStop(0.4, "rgba(255,255,255,0.35)");
        g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, w, h);
      });
    },

    buildGround: function () {
      var ground = new THREE.Mesh(
        new THREE.PlaneGeometry(220, 220),
        new THREE.MeshStandardMaterial({
          map: this.texRoad, roughness: 0.25, metalness: 0.45
        })
      );
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      this.group.add(ground);

      // Perimeter walls (220x220 m)
      var wallMat = new THREE.MeshStandardMaterial({ color: 0x100d1e, roughness: 0.8 });
      var perim = [
        [0, 5, -108, 220, 10, 4],
        [0, 5, 108, 220, 10, 4],
        [-108, 5, 0, 4, 10, 220],
        [108, 5, 0, 4, 10, 220]
      ];
      for (var i = 0; i < perim.length; i++) {
        var p = perim[i];
        var m = new THREE.Mesh(new THREE.BoxGeometry(p[3], p[4], p[5]), wallMat);
        m.position.set(p[0], p[1], p[2]);
        this.group.add(m);
        S.Physics.addBox(p[0] - p[3] / 2, 0, p[2] - p[5] / 2, p[0] + p[3] / 2, p[4], p[2] + p[5] / 2, "wall");
      }
    },

    addNeonSign: function (text, colorHex, x, y, z, rotY, w, h) {
      var tex = makeCanvasTex(256, 64, function (ctx, cw, ch) {
        ctx.fillStyle = "#080614";
        ctx.fillRect(0, 0, cw, ch);
        ctx.strokeStyle = colorHex;
        ctx.lineWidth = 4;
        ctx.strokeRect(4, 4, cw - 8, ch - 8);
        ctx.fillStyle = colorHex;
        ctx.font = "bold 30px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(text, cw / 2, ch / 2);
      });
      var mat = new THREE.MeshBasicMaterial({ map: tex });
      var sign = new THREE.Mesh(new THREE.PlaneGeometry(w || 5.5, h || 1.5), mat);
      sign.position.set(x, y, z);
      sign.rotation.y = rotY || 0;
      this.group.add(sign);

      // Fake bloom glow sprite
      var spMat = new THREE.SpriteMaterial({
        map: this.texGlow, color: new THREE.Color(colorHex),
        transparent: true, opacity: 0.48, blending: THREE.AdditiveBlending, depthWrite: false
      });
      var sp = new THREE.Sprite(spMat);
      sp.position.set(x, y, z);
      sp.scale.set((w || 5.5) * 1.4, (h || 1.5) * 2.4, 1);
      this.group.add(sp);
      this.flickerLights.push({ sprite: sp, base: 0.45, phase: Math.random() * 10 });
    },

    buildDistrict: function () {
      var bldgData = [];
      var coverData = [];
      var lampData = [];

      function pushBox(arr, cx, cy, cz, sx, sy, sz, addPhys, tag) {
        arr.push({ x: cx, y: cy, z: cz, sx: sx, sy: sy, sz: sz });
        if (addPhys !== false) {
          S.Physics.addBox(cx - sx / 2, cy - sy / 2, cz - sz / 2, cx + sx / 2, cy + sy / 2, cz + sz / 2, tag || "solid");
        }
      }

      // 1. Buildings framing Main Street & 4 Side Alleys
      var blocks = [
        // West side north/south (leaving 2 alleys at z=-44 and z=+6)
        [-34, 12, -74, 28, 24, 34],
        [-36, 15, -20, 26, 30, 32],
        [-78, 14, -55, 34, 28, 44],
        [-78, 12, -8,  32, 24, 30],
        // South-west behind parking
        [-42, 14, 78, 44, 28, 28],
        // East side north (leaving alley at z=-46)
        [36, 14, -74, 28, 28, 34],
        [78, 16, -68, 34, 32, 42],
        [78, 13, -18, 28, 26, 36],
        // South-east behind construction
        [44, 14, 82, 46, 28, 24]
      ];
      for (var i = 0; i < blocks.length; i++) {
        var b = blocks[i];
        pushBox(bldgData, b[0], b[1], b[2], b[3], b[4], b[5], true, "building");
      }

      // 2. Enterable Neon Club (x: 24..54, z: -34..-4, entrance facing West x=24)
      pushBox(bldgData, 39, 3.5, -34, 30, 7, 1.4, true, "wall"); // North wall
      pushBox(bldgData, 39, 3.5, -4,  30, 7, 1.4, true, "wall"); // South wall
      pushBox(bldgData, 54, 3.5, -19, 1.4, 7, 30, true, "wall"); // East wall
      pushBox(bldgData, 24, 3.5, -28, 1.4, 7, 12, true, "wall"); // West wall north
      pushBox(bldgData, 24, 3.5, -10, 1.4, 7, 12, true, "wall"); // West wall south
      pushBox(bldgData, 39, 7.2, -19, 31, 0.8, 31, true, "roof"); // Club roof
      // Club interior cover & DJ booth
      pushBox(coverData, 47, 0.7, -19, 4, 1.4, 8, true, "cover");
      pushBox(coverData, 34, 0.65, -24, 2.6, 1.3, 2.6, true, "cover");
      pushBox(coverData, 34, 0.65, -14, 2.6, 1.3, 2.6, true, "cover");

      // 3. Rooftop Deck + Walkable Stairs (west of plaza, x: -22..-10, z: 16..34)
      pushBox(bldgData, -16, 2.1, 28, 12, 4.2, 12, true, "rooftop");
      // 14 stairs (rise 0.30m <= stepHeight 0.35m, run 0.8m) leading from z=11 to z=22
      for (var st = 0; st < 14; st++) {
        var sh = (st + 1) * 0.30;
        pushBox(coverData, -16, sh * 0.5, 11.2 + st * 0.8, 3.8, sh, 0.85, true, "stairs");
      }
      // Rooftop low parapet cover
      pushBox(coverData, -10.5, 4.7, 28, 0.8, 1.0, 11, true, "cover");

      // 4. Central Plaza + Neon Fountain (around x: 0, z: -20)
      pushBox(coverData, 0, 0.6, -20, 6.5, 1.2, 6.5, true, "fountain");
      var fSpire = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.9, 3.4, 8),
        new THREE.MeshBasicMaterial({ color: 0x00f0ff })
      );
      fSpire.position.set(0, 2.2, -20);
      this.group.add(fSpire);

      // 5. Parking Lot (x: -60..-22, z: 12..56) — cyber cars as cover
      var cars = [
        [-30, 22], [-42, 22], [-52, 22],
        [-30, 36], [-44, 36], [-54, 36],
        [-34, 48], [-48, 48]
      ];
      for (var c = 0; c < cars.length; c++) {
        pushBox(coverData, cars[c][0], 0.75, cars[c][1], 4.4, 1.5, 2.2, true, "car");
      }

      // 6. Construction Yard (x: 24..64, z: 20..62) — containers & concrete barriers
      var containers = [
        [32, 1.5, 30, 3.2, 3.0, 8.5],
        [48, 1.5, 28, 8.5, 3.0, 3.2],
        [42, 1.5, 46, 3.2, 3.0, 9.0],
        [56, 1.5, 48, 8.0, 3.0, 3.2],
        [30, 0.7, 52, 5.0, 1.4, 1.4]
      ];
      for (var ct = 0; ct < containers.length; ct++) {
        var cc = containers[ct];
        pushBox(coverData, cc[0], cc[1], cc[2], cc[3], cc[4], cc[5], true, "cover");
      }

      // 7. Street Cover every 6-10m along Main Street & Plaza & Alleys
      var covers = [
        [-6, -78], [6, -70], [-5, -60], [7, -52],
        [-8, -32], [8, -32], [-9, -10], [9, -10],
        [-6, 4], [6, 10], [-4, 20], [7, 26],
        [-6, 38], [6, 46], [-5, 58], [6, 66],
        [-4, 78], [5, 86],
        // Alley cover
        [-30, -46], [-50, -46], [36, -46], [54, -46],
        [-28, 6], [26, 8]
      ];
      for (var cv = 0; cv < covers.length; cv++) {
        var cx = covers[cv][0], cz = covers[cv][1];
        var wide = cv % 2 === 0;
        pushBox(coverData, cx, 0.65, cz, wide ? 3.2 : 1.4, 1.3, wide ? 1.4 : 3.2, true, "cover");
        this.coverPoints.push({ x: cx, z: cz });
      }

      // 8. Street Lamps along Main Street
      for (var lz = -85; lz <= 85; lz += 22) {
        lampData.push({ x: -13, y: 3.5, z: lz, sx: 0.25, sy: 7, sz: 0.25 });
        lampData.push({ x: 13,  y: 3.5, z: lz, sx: 0.25, sy: 7, sz: 0.25 });
      }

      // Build InstancedMeshes (keeps draw calls very low!)
      this.createInstanced(bldgData, new THREE.MeshStandardMaterial({
        map: this.texBldg, roughness: 0.65, metalness: 0.2
      }), true);
      this.createInstanced(coverData, new THREE.MeshStandardMaterial({
        map: this.texCover, roughness: 0.55, metalness: 0.3
      }), true);
      this.createInstanced(lampData, new THREE.MeshBasicMaterial({ color: 0x223355 }), false);

      // Neon signs
      this.addNeonSign("SOHO CLUB", "#ff2a85", 23.1, 5.2, -19, -Math.PI / 2, 7, 1.8);
      this.addNeonSign("RAMEN 24H", "#00f0ff", -22.8, 7.5, -20, Math.PI / 2, 6.5, 1.6);
      this.addNeonSign("SYNDICATE", "#ff2a85", -19.8, 9.0, -72, Math.PI / 2, 7.5, 1.8);
      this.addNeonSign("CYBER TECH", "#00ff99", 21.8, 8.5, -72, -Math.PI / 2, 7, 1.6);
      this.addNeonSign("PARKING", "#ffde59", -24, 4.5, 16, 0, 5.5, 1.4);
      this.addNeonSign("DANGER ZONE", "#ff5522", 28, 4.5, 22, 0, 6, 1.4);
      this.addNeonSign("ARCADE VIP", "#a040ff", 0, 10, -105.5, 0, 10, 2.2);
      this.addNeonSign("SOHO PLAZA", "#00f0ff", 0, 10, 105.5, Math.PI, 10, 2.2);
    },

    createInstanced: function (list, mat, castShadow) {
      if (!list.length) return;
      var geo = new THREE.BoxGeometry(1, 1, 1);
      var im = new THREE.InstancedMesh(geo, mat, list.length);
      im.castShadow = !!castShadow;
      im.receiveShadow = true;
      var dummy = new THREE.Object3D();
      for (var i = 0; i < list.length; i++) {
        var d = list[i];
        dummy.position.set(d.x, d.y, d.z);
        dummy.scale.set(d.sx, d.sy, d.sz);
        dummy.updateMatrix();
        im.setMatrixAt(i, dummy.matrix);
      }
      im.instanceMatrix.needsUpdate = true;
      this.group.add(im);
    },

    buildSpawnsAndPickups: function () {
      // 8 Player Spawns
      this.playerSpawns = [
        { x: 0, y: 0, z: 86 },
        { x: 0, y: 0, z: -86 },
        { x: -38, y: 0, z: 30 },
        { x: 38, y: 0, z: 38 },
        { x: 18, y: 0, z: -19 },
        { x: -16, y: 4.3, z: 28 },
        { x: -45, y: 0, z: -46 },
        { x: 45, y: 0, z: -46 }
      ];

      // 44 Enemy Spawns across all zones
      this.enemySpawns = [
        // Main Street
        { x: -8, z: -82 }, { x: 8, z: -78 }, { x: -6, z: -64 }, { x: 7, z: -56 },
        { x: -10, z: -38 }, { x: 10, z: -36 }, { x: -11, z: -18 }, { x: 11, z: -16 },
        { x: -8, z: 0 }, { x: 8, z: 4 }, { x: -7, z: 18 }, { x: 9, z: 22 },
        { x: -8, z: 36 }, { x: 8, z: 42 }, { x: -7, z: 54 }, { x: 7, z: 60 },
        { x: -9, z: 72 }, { x: 9, z: 74 },
        // Plaza
        { x: -14, z: -26 }, { x: 14, z: -26 }, { x: -14, z: -12 }, { x: 14, z: -12 },
        // 4 Alleys
        { x: -36, z: -46 }, { x: -56, z: -46 }, { x: 36, z: -46 }, { x: 56, z: -46 },
        { x: -32, z: 6 }, { x: -50, z: 6 }, { x: 32, z: 8 }, { x: 52, z: 8 },
        // Neon Club interior
        { x: 32, z: -28 }, { x: 42, z: -28 }, { x: 32, z: -10 }, { x: 42, z: -10 },
        { x: 49, z: -19 },
        // Parking Lot
        { x: -28, z: 28 }, { x: -46, z: 28 }, { x: -36, z: 44 }, { x: -52, z: 50 },
        // Construction Yard
        { x: 36, z: 26 }, { x: 52, z: 34 }, { x: 36, z: 46 }, { x: 52, z: 56 },
        // Rooftop
        { x: -16, y: 4.3, z: 28 }
      ];

      // Pickups in alley dead-ends & key spots
      var pkDefs = [
        { type: "medkit",  x: -58, z: -46, color: 0x00ff88 },
        { type: "armor",   x: 58,  z: -46, color: 0x00c8ff },
        { type: "ammo",    x: -56, z: 6,   color: 0xffde59 },
        { type: "grenade", x: 56,  z: 8,   color: 0xff5522 },
        { type: "medkit",  x: 49,  z: -28, color: 0x00ff88 },
        { type: "ammo",    x: -16, y: 4.3, z: 31, color: 0xffde59 },
        { type: "armor",   x: -48, z: 42,  color: 0x00c8ff },
        { type: "medkit",  x: 46,  z: 40,  color: 0x00ff88 }
      ];
      var pkGeo = new THREE.BoxGeometry(0.65, 0.45, 0.65);
      for (var i = 0; i < pkDefs.length; i++) {
        var d = pkDefs[i];
        var m = new THREE.Mesh(pkGeo, new THREE.MeshBasicMaterial({ color: d.color }));
        m.position.set(d.x, (d.y || 0) + 0.55, d.z);
        this.group.add(m);
        this.pickups.push({
          type: d.type, mesh: m, x: d.x, y: d.y || 0, z: d.z,
          active: true, respawnTimer: 0
        });
      }
    },

    spawnAirdrop: function (x, z) {
      var m = new THREE.Mesh(
        new THREE.BoxGeometry(1.1, 0.9, 1.1),
        new THREE.MeshBasicMaterial({ color: 0xff2a85 })
      );
      m.position.set(x, 0.65, z);
      this.group.add(m);
      this.pickups.push({
        type: "airdrop", mesh: m, x: x, y: 0, z: z,
        active: true, respawnTimer: 0, temporary: true
      });
    },

    setupTrainingTargets: function (enable) {
      // Clear old targets
      for (var i = 0; i < this.trainingTargets.length; i++) {
        this.group.remove(this.trainingTargets[i].mesh);
      }
      this.trainingTargets.length = 0;
      if (!enable) return;

      var positions = [
        [-6, 1.5, 68], [0, 1.5, 64], [6, 1.5, 68],
        [-8, 1.5, 52], [0, 1.5, 48], [8, 1.5, 52],
        [-4, 1.5, 36], [4, 1.5, 36]
      ];
      var geo = new THREE.BoxGeometry(0.9, 1.6, 0.25);
      for (var t = 0; t < positions.length; t++) {
        var p = positions[t];
        var mat = new THREE.MeshBasicMaterial({ color: 0xff2a85 });
        var mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(p[0], p[1], p[2]);
        this.group.add(mesh);
        this.trainingTargets.push({
          mesh: mesh, baseX: p[0], y: p[1], z: p[2],
          hp: 60, maxHp: 60, respawn: 0, moveAmp: t >= 3 ? 3.5 : 0, phase: t * 1.1
        });
      }
    },

    resetPickups: function () {
      for (var i = this.pickups.length - 1; i >= 0; i--) {
        var p = this.pickups[i];
        if (p.temporary) {
          this.group.remove(p.mesh);
          this.pickups.splice(i, 1);
        } else {
          p.active = true;
          p.respawnTimer = 0;
          p.mesh.visible = true;
        }
      }
    },

    update: function (dt) {
      this.flickerTime += dt;
      for (var i = 0; i < this.flickerLights.length; i++) {
        var fl = this.flickerLights[i];
        var f = Math.sin(this.flickerTime * 7 + fl.phase) * Math.sin(this.flickerTime * 19 + fl.phase);
        fl.sprite.material.opacity = fl.base + (f > 0.7 ? -0.22 : f * 0.08);
      }

      for (var p = 0; p < this.pickups.length; p++) {
        var pk = this.pickups[p];
        if (pk.active) {
          pk.mesh.rotation.y += dt * 1.8;
          pk.mesh.position.y = pk.y + 0.55 + Math.sin(this.flickerTime * 3 + p) * 0.12;
        } else if (!pk.temporary) {
          pk.respawnTimer -= dt;
          if (pk.respawnTimer <= 0) {
            pk.active = true;
            pk.mesh.visible = true;
          }
        }
      }

      for (var t = 0; t < this.trainingTargets.length; t++) {
        var tg = this.trainingTargets[t];
        if (tg.respawn > 0) {
          tg.respawn -= dt;
          if (tg.respawn <= 0) {
            tg.hp = tg.maxHp;
            tg.mesh.visible = true;
          }
        } else if (tg.moveAmp > 0) {
          tg.mesh.position.x = tg.baseX + Math.sin(this.flickerTime * 1.8 + tg.phase) * tg.moveAmp;
        }
      }
    }
  };

  S.World = World;
})();
