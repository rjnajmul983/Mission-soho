(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  // Global error overlay
  function showErr(msg) {
    var ov = document.getElementById("error-overlay");
    var tx = document.getElementById("error-text");
    if (ov && tx) {
      tx.textContent = (tx.textContent ? tx.textContent + "\n" : "") + String(msg);
      ov.classList.remove("hidden");
    }
  }
  window.onerror = function (msg, src, line, col, err) {
    showErr(msg + " (" + src + ":" + line + ":" + col + ")" + (err && err.stack ? "\n" + err.stack : ""));
    return false;
  };
  window.addEventListener("unhandledrejection", function (ev) {
    showErr("Promise rejection: " + (ev.reason && ev.reason.stack ? ev.reason.stack : ev.reason));
  });
  document.addEventListener("DOMContentLoaded", function () {
    var btn = document.getElementById("error-dismiss");
    if (btn) btn.addEventListener("click", function () {
      var ov = document.getElementById("error-overlay");
      if (ov) ov.classList.add("hidden");
    });
  });

  var STORAGE_KEY = "mission_soho_save_v1";
  var SCHEMA_VERSION = 1;

  function makePresets() {
    return {
      freefire: {
        fire:     { x: 86, y: 72, s: 1.0, a: 0.85 },
        fireLeft: { x: 14, y: 38, s: 1.0, a: 0.80 },
        ads:      { x: 92, y: 46, s: 1.0, a: 0.80 },
        zoom:     { x: 82, y: 46, s: 0.9, a: 0.85 },
        reload:   { x: 75, y: 84, s: 0.95, a: 0.80 },
        jump:     { x: 92, y: 28, s: 0.95, a: 0.80 },
        crouch:   { x: 76, y: 66, s: 0.95, a: 0.80 },
        grenade:  { x: 66, y: 84, s: 0.9, a: 0.80 },
        interact: { x: 66, y: 58, s: 1.0, a: 0.90 },
        pause:    { x: 94, y: 9,  s: 0.9, a: 0.75 },
        slots:    { x: 50, y: 86, s: 0.95, a: 0.85 }
      },
      pubg: {
        fire:     { x: 85, y: 74, s: 1.05, a: 0.85 },
        fireLeft: { x: 12, y: 32, s: 1.0, a: 0.85 },
        ads:      { x: 92, y: 50, s: 1.05, a: 0.85 },
        zoom:     { x: 82, y: 50, s: 0.9, a: 0.85 },
        reload:   { x: 74, y: 82, s: 0.95, a: 0.80 },
        jump:     { x: 92, y: 31, s: 1.0, a: 0.80 },
        crouch:   { x: 84, y: 89, s: 0.95, a: 0.80 },
        grenade:  { x: 64, y: 84, s: 0.9, a: 0.80 },
        interact: { x: 68, y: 56, s: 1.0, a: 0.90 },
        pause:    { x: 94, y: 9,  s: 0.9, a: 0.75 },
        slots:    { x: 48, y: 86, s: 0.95, a: 0.85 }
      },
      classic: {
        fire:     { x: 88, y: 76, s: 1.0, a: 0.85 },
        fireLeft: { x: 14, y: 42, s: 0.95, a: 0.75 },
        ads:      { x: 76, y: 76, s: 1.0, a: 0.80 },
        zoom:     { x: 76, y: 58, s: 0.9, a: 0.85 },
        reload:   { x: 88, y: 54, s: 0.95, a: 0.80 },
        jump:     { x: 92, y: 36, s: 0.95, a: 0.80 },
        crouch:   { x: 78, y: 38, s: 0.95, a: 0.80 },
        grenade:  { x: 66, y: 76, s: 0.9, a: 0.80 },
        interact: { x: 65, y: 55, s: 1.0, a: 0.90 },
        pause:    { x: 94, y: 9,  s: 0.9, a: 0.75 },
        slots:    { x: 50, y: 87, s: 0.95, a: 0.85 }
      }
    };
  }

  function clone(o) {
    return JSON.parse(JSON.stringify(o));
  }

  function defaultData() {
    var presets = makePresets();
    presets.custom = clone(presets.freefire);
    return {
      version: SCHEMA_VERSION,
      progress: {
        cash: 250,
        xp: 0,
        level: 1,
        unlockedMission: 1,
        stars: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
        tutorialDone: false,
        bestSurvivalWave: 0,
        upgrades: { damage: 0, mag: 0, armor: 0, reload: 0, speed: 0 }
      },
      settings: {
        controls: {
          preset: "freefire",
          fireMode: "hold",
          adsMode: "toggle",
          joyMode: "floating",
          leftFire: false,
          leftHanded: false,
          invertY: false,
          gyro: false,
          haptics: true,
          sensHip: 100,
          sensAds: 60,
          sens4x: 35,
          sens8x: 20,
          sensGyro: 100,
          smooth: 10,
          aimAssist: 65
        },
        layouts: presets,
        graphics: {
          tier: "med",
          fpsCap: 60,
          fov: 75,
          rain: true,
          showFps: false
        },
        audio: {
          master: 80,
          sfx: 90,
          music: 50
        },
        gameplay: {
          difficulty: "normal",
          autoReload: true,
          crosshairStyle: "cross",
          crosshairColor: "cyan"
        }
      }
    };
  }

  function mergeDeep(base, src) {
    if (!src || typeof src !== "object") return base;
    var k;
    for (k in base) {
      if (!Object.prototype.hasOwnProperty.call(base, k)) continue;
      if (src[k] === undefined || src[k] === null) continue;
      if (typeof base[k] === "object" && !Array.isArray(base[k])) {
        base[k] = mergeDeep(base[k], src[k]);
      } else if (typeof src[k] === typeof base[k]) {
        base[k] = src[k];
      }
    }
    return base;
  }

  var Save = {
    data: defaultData(),
    defaultPresets: makePresets,

    load: function () {
      var def = defaultData();
      try {
        var raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) {
          var parsed = JSON.parse(raw);
          if (parsed && typeof parsed === "object") {
            if (!parsed.version || parsed.version < SCHEMA_VERSION) {
              parsed.version = SCHEMA_VERSION;
            }
            this.data = mergeDeep(def, parsed);
            return this.data;
          }
        }
      } catch (e) {
        // Corrupt or blocked storage: fall back safely
      }
      this.data = def;
      return this.data;
    },

    save: function () {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
        return true;
      } catch (e) {
        return false;
      }
    },

    resetProgress: function () {
      var def = defaultData();
      this.data.progress = def.progress;
      this.save();
    },

    getLayout: function (presetName) {
      var name = presetName || this.data.settings.controls.preset || "freefire";
      var lays = this.data.settings.layouts;
      if (!lays[name]) {
        var defP = makePresets();
        lays[name] = clone(defP[name] || defP.freefire);
      }
      return lays[name];
    },

    resetLayout: function (presetName) {
      var defP = makePresets();
      var base = defP[presetName] || defP.freefire;
      this.data.settings.layouts[presetName] = clone(base);
      this.save();
      return this.data.settings.layouts[presetName];
    },

    addReward: function (cash, xp) {
      var p = this.data.progress;
      p.cash += Math.max(0, Math.round(cash));
      p.xp += Math.max(0, Math.round(xp));
      while (p.xp >= p.level * 500) {
        p.xp -= p.level * 500;
        p.level += 1;
      }
      this.save();
    },

    vibrate: function (ms) {
      if (!this.data.settings.controls.haptics) return;
      try {
        if (window.AndroidBridge && typeof window.AndroidBridge.vibrate === "function") {
          window.AndroidBridge.vibrate(ms);
        } else if (navigator.vibrate) {
          navigator.vibrate(ms);
        }
      } catch (e) {}
    }
  };

  Save.load();
  S.Save = Save;
})();
