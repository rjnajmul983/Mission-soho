(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var CELL = 2;
  var SIZE = 110; // 220m / 2m
  var HALF = 110;

  var AI = {
    grid: null,
    _gScore: null,
    _fScore: null,
    _cameFrom: null,
    _closed: null,
    _stamp: 0,
    _open: [],

    init: function () {
      var total = SIZE * SIZE;
      this.grid = new Uint8Array(total);
      this._gScore = new Float32Array(total);
      this._fScore = new Float32Array(total);
      this._cameFrom = new Int32Array(total);
      this._closed = new Int32Array(total);

      for (var gz = 0; gz < SIZE; gz++) {
        var wz = -HALF + gz * CELL + 1;
        for (var gx = 0; gx < SIZE; gx++) {
          var wx = -HALF + gx * CELL + 1;
          this.grid[gz * SIZE + gx] = S.Physics.pointBlockedXZ(wx, wz, 1.0) ? 1 : 0;
        }
      }
    },

    toCell: function (v) {
      var c = Math.floor((v + HALF) / CELL);
      return c < 0 ? 0 : (c >= SIZE ? SIZE - 1 : c);
    },

    toWorld: function (c) {
      return -HALF + c * CELL + 1;
    },

    // Bounded Grid A* on 2m nav grid + simple path smoothing
    findPath: function (sx, sz, tx, tz, outPath) {
      outPath.length = 0;
      if (!this.grid) return outPath;

      var scx = this.toCell(sx), scz = this.toCell(sz);
      var tcx = this.toCell(tx), tcz = this.toCell(tz);
      var startIdx = scz * SIZE + scx;
      var goalIdx = tcz * SIZE + tcx;
      if (startIdx === goalIdx) {
        outPath.push({ x: tx, z: tz });
        return outPath;
      }

      var stamp = ++this._stamp;
      var open = this._open;
      open.length = 0;

      this._gScore[startIdx] = 0;
      this._fScore[startIdx] = Math.abs(tcx - scx) + Math.abs(tcz - scz);
      this._cameFrom[startIdx] = -1;
      this._closed[startIdx] = -stamp; // in open set
      open.push(startIdx);

      var bestIdx = startIdx;
      var bestH = this._fScore[startIdx];
      var dirs = [1, 0, -1, 0, 0, 1, 0, -1, 1, 1, -1, 1, 1, -1, -1, -1];
      var iters = 0;

      while (open.length > 0 && iters < 180) {
        iters++;
        // Pop lowest fScore
        var bi = 0, bf = this._fScore[open[0]];
        for (var i = 1; i < open.length; i++) {
          var f = this._fScore[open[i]];
          if (f < bf) { bf = f; bi = i; }
        }
        var cur = open[bi];
        open[bi] = open[open.length - 1];
        open.pop();

        if (cur === goalIdx) { bestIdx = cur; break; }
        this._closed[cur] = stamp;

        var cx = cur % SIZE;
        var cz = (cur - cx) / SIZE;
        var cg = this._gScore[cur];

        for (var d = 0; d < 16; d += 2) {
          var nx = cx + dirs[d], nz = cz + dirs[d + 1];
          if (nx < 1 || nx >= SIZE - 1 || nz < 1 || nz >= SIZE - 1) continue;
          var nIdx = nz * SIZE + nx;
          if (this.grid[nIdx] === 1 || this._closed[nIdx] === stamp) continue;

          var stepCost = (dirs[d] !== 0 && dirs[d + 1] !== 0) ? 1.41 : 1.0;
          var tentG = cg + stepCost;
          var inOpen = (this._closed[nIdx] === -stamp);
          if (!inOpen || tentG < this._gScore[nIdx]) {
            this._cameFrom[nIdx] = cur;
            this._gScore[nIdx] = tentG;
            var h = Math.abs(tcx - nx) + Math.abs(tcz - nz);
            this._fScore[nIdx] = tentG + h;
            if (h < bestH) { bestH = h; bestIdx = nIdx; }
            if (!inOpen) {
              this._closed[nIdx] = -stamp;
              open.push(nIdx);
            }
          }
        }
      }

      // Reconstruct path (keep every 2nd node + smoothing)
      var raw = [];
      var k = bestIdx;
      var guard = 0;
      while (k !== -1 && k !== startIdx && guard < 120) {
        var rx = k % SIZE;
        var rz = (k - rx) / SIZE;
        raw.push({ x: this.toWorld(rx), z: this.toWorld(rz) });
        k = this._cameFrom[k];
        guard++;
      }
      raw.reverse();

      // Path smoothing: skip intermediate waypoints when direct LOS exists
      if (raw.length <= 2) {
        for (var r = 0; r < raw.length; r++) outPath.push(raw[r]);
      } else {
        var anchorX = sx, anchorZ = sz;
        for (var j = 0; j < raw.length; j++) {
          var isLast = (j === raw.length - 1);
          if (isLast || !S.Physics.hasLOS(anchorX, 1.0, anchorZ, raw[j].x, 1.0, raw[j].z)) {
            var pick = (j > 0 && !isLast) ? raw[j - 1] : raw[j];
            outPath.push(pick);
            anchorX = pick.x;
            anchorZ = pick.z;
          }
        }
      }
      return outPath;
    },

    // Vision cone 90 deg, range 40m + LOS raycast
    canSeePlayer: function (enemy, player) {
      if (!player.alive) return false;
      var dx = player.pos.x - enemy.x;
      var dz = player.pos.z - enemy.z;
      var distSq = dx * dx + dz * dz;
      var maxR = enemy.type === "sniper" ? 55 : 40;
      if (distSq > maxR * maxR) return false;

      var dist = Math.sqrt(distSq);
      if (dist > 3.5) {
        var fx = Math.sin(enemy.yaw);
        var fz = Math.cos(enemy.yaw);
        var dot = (dx * fx + dz * fz) / dist;
        if (dot < 0.707) return false; // 90 deg FOV (+/- 45 deg)
      }
      return S.Physics.hasLOS(enemy.x, enemy.y + 1.45, enemy.z, player.pos.x, player.pos.y + 1.2, player.pos.z);
    },

    findNearestCover: function (ex, ez, px, pz) {
      var list = S.World.coverPoints;
      var best = null, bestScore = 1e9;
      for (var i = 0; i < list.length; i++) {
        var c = list[i];
        var de = Math.hypot(c.x - ex, c.z - ez);
        var dp = Math.hypot(c.x - px, c.z - pz);
        if (de < 22 && dp > 6 && dp < 38) {
          var score = de;
          if (score < bestScore) {
            bestScore = score;
            // Stand on side of cover opposite to player
            var ox = c.x - px, oz = c.z - pz;
            var l = Math.hypot(ox, oz) || 1;
            best = { x: c.x + (ox / l) * 2.2, z: c.z + (oz / l) * 2.2 };
          }
        }
      }
      return best;
    }
  };

  S.AI = AI;
})();
