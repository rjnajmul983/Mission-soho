(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var UPGRADES = [
    { key: "damage", name: "WEAPON DAMAGE", desc: "+12% damage per level", baseCost: 200 },
    { key: "mag",    name: "EXTENDED MAGS", desc: "+15% magazine size per level", baseCost: 180 },
    { key: "armor",  name: "KEVLAR PLATING",desc: "+15 max armor per level", baseCost: 220 },
    { key: "reload", name: "FAST HANDS",    desc: "-8% reload time per level", baseCost: 180 },
    { key: "speed",  name: "CYBER BOOTS",   desc: "+6% move speed per level", baseCost: 200 }
  ];

  var UI = {
    selectedMissionId: 1,
    settingsReturnTo: "menu",

    init: function () {
      var self = this;
      function on(id, fn) {
        var el = document.getElementById(id);
        if (el) el.addEventListener("click", function () { S.Audio.playClick(); fn(); });
      }

      // Menu buttons
      on("btn-campaign", function () { self.showCampaign(); });
      on("btn-survival", function () { self.deploy("survival"); });
      on("btn-training", function () { self.deploy("training"); });
      on("btn-shop", function () { self.showShop(); });
      on("btn-settings", function () { self.openSettings("menu"); });
      on("btn-exit", function () {
        if (window.AndroidBridge && window.AndroidBridge.exitApp) window.AndroidBridge.exitApp();
      });

      // Campaign & Briefing
      on("btn-campaign-back", function () { self.showMenu(); });
      on("btn-brief-back", function () { self.showCampaign(); });
      on("btn-brief-start", function () { self.deploy("campaign", self.selectedMissionId); });

      // Shop
      on("btn-shop-back", function () { self.showMenu(); });

      // Pause
      on("btn-resume", function () { self.resumeGame(); });
      on("btn-pause-settings", function () { self.openSettings("pause"); });
      on("btn-restart", function () {
        if (S.Missions.mode === "campaign") self.deploy("campaign", S.Missions.current.id);
        else self.deploy(S.Missions.mode);
      });
      on("btn-quit-menu", function () { self.showMenu(); });

      // Result
      on("btn-res-menu", function () { self.showMenu(); });
      on("btn-res-retry", function () {
        if (S.Missions.mode === "campaign") self.deploy("campaign", S.Missions.current.id);
        else self.deploy(S.Missions.mode);
      });
      on("btn-res-next", function () {
        var nextId = Math.min(5, (S.Missions.current ? S.Missions.current.id : 1) + 1);
        self.deploy("campaign", nextId);
      });

      // FPS auto-suggest prompt
      on("btn-fps-accept", function () {
        var box = document.getElementById("fps-suggest-box");
        var tier = box.dataset.suggestTier || "low";
        S.Save.data.settings.graphics.tier = tier;
        S.Save.save();
        S.Core.applyGraphics();
        box.classList.add("hidden");
      });
      on("btn-fps-dismiss", function () {
        document.getElementById("fps-suggest-box").classList.add("hidden");
      });

      this.bindSettings();
    },

    hideAllScreens: function () {
      var ids = [
        "screen-loading", "screen-menu", "screen-campaign", "screen-briefing",
        "screen-shop", "screen-settings", "screen-hud", "screen-pause", "screen-result"
      ];
      for (var i = 0; i < ids.length; i++) {
        var el = document.getElementById(ids[i]);
        if (el) el.classList.add("hidden");
      }
    },

    showMenu: function () {
      S.Input.releaseAll();
      S.Missions.active = false;
      S.Core.setState("MENU");
      this.hideAllScreens();
      var p = S.Save.data.progress;
      document.getElementById("menu-level").textContent = p.level;
      document.getElementById("menu-xp").textContent = p.xp;
      document.getElementById("menu-cash").textContent = p.cash;
      document.getElementById("menu-tutorial-badge").classList.toggle("hidden", !!p.tutorialDone);
      document.getElementById("screen-menu").classList.remove("hidden");
    },

    showCampaign: function () {
      this.hideAllScreens();
      var list = document.getElementById("mission-list");
      list.innerHTML = "";
      var prog = S.Save.data.progress;
      var self = this;

      for (var i = 0; i < S.Missions.CAMPAIGN.length; i++) {
        (function (m) {
          var locked = m.id > prog.unlockedMission;
          var st = prog.stars[m.id] || 0;
          var card = document.createElement("div");
          card.className = "card" + (locked ? " locked" : "");
          card.innerHTML =
            "<h3>" + m.title + "</h3>" +
            "<p>" + m.desc + "</p>" +
            "<div class='stars'>" + "★".repeat(st) + "☆".repeat(3 - st) + "</div>" +
            "<button class='btn btn-sm " + (locked ? "" : "btn-cyan") + "'>" + (locked ? "LOCKED" : "SELECT") + "</button>";
          if (!locked) {
            card.querySelector("button").addEventListener("click", function () {
              S.Audio.playClick();
              self.showBriefing(m);
            });
          }
          list.appendChild(card);
        })(S.Missions.CAMPAIGN[i]);
      }
      document.getElementById("screen-campaign").classList.remove("hidden");
    },

    showBriefing: function (m) {
      this.selectedMissionId = m.id;
      this.hideAllScreens();
      document.getElementById("brief-title").textContent = m.title;
      document.getElementById("brief-desc").textContent = m.desc;
      document.getElementById("brief-obj").textContent = m.objective;
      document.getElementById("brief-reward").textContent = "$" + m.cash + " + " + m.xp + " XP";
      document.getElementById("screen-briefing").classList.remove("hidden");
    },

    showShop: function () {
      this.hideAllScreens();
      var prog = S.Save.data.progress;
      document.getElementById("shop-cash").textContent = prog.cash;
      var list = document.getElementById("shop-list");
      list.innerHTML = "";
      var self = this;

      for (var i = 0; i < UPGRADES.length; i++) {
        (function (u) {
          var lvl = prog.upgrades[u.key] || 0;
          var cost = u.baseCost * (lvl + 1);
          var maxed = lvl >= 5;
          var canBuy = !maxed && prog.cash >= cost;
          var card = document.createElement("div");
          card.className = "card";
          card.innerHTML =
            "<h3>" + u.name + " (LVL " + lvl + "/5)</h3>" +
            "<p>" + u.desc + "</p>" +
            "<button class='btn btn-sm " + (canBuy ? "btn-cyan" : "btn-dim") + "'>" +
            (maxed ? "MAXED" : "UPGRADE $" + cost) + "</button>";
          if (canBuy) {
            card.querySelector("button").addEventListener("click", function () {
              S.Audio.playPickup();
              prog.cash -= cost;
              prog.upgrades[u.key] = lvl + 1;
              S.Save.save();
              self.showShop();
            });
          }
          list.appendChild(card);
        })(UPGRADES[i]);
      }
      document.getElementById("screen-shop").classList.remove("hidden");
    },

    deploy: function (mode, missionId) {
      this.hideAllScreens();
      S.Input.releaseAll();
      document.getElementById("screen-hud").classList.remove("hidden");
      S.Core.setState("PLAY");
      S.Input.applyLayout();
      S.HUD.applyCrosshairStyle();
      if (mode === "campaign") S.Missions.startCampaign(missionId || 1);
      else if (mode === "survival") S.Missions.startSurvival();
      else S.Missions.startTraining();
    },

    pauseGame: function () {
      if (S.Core.state !== "PLAY") return;
      S.Input.releaseAll();
      S.Core.setState("PAUSE");
      document.getElementById("screen-pause").classList.remove("hidden");
    },

    resumeGame: function () {
      if (S.Core.state !== "PAUSE") return;
      document.getElementById("screen-pause").classList.add("hidden");
      S.Core.setState("PLAY");
    },

    showResult: function (victory, stars, kills, headshots, elapsed, cash, xp) {
      S.Input.releaseAll();
      S.Core.setState("RESULT");
      document.getElementById("res-title").textContent = victory ? "MISSION COMPLETE" : "MISSION FAILED";
      document.getElementById("res-stars").textContent = "★".repeat(stars) + "☆".repeat(3 - stars);
      document.getElementById("res-kills").textContent = kills;
      document.getElementById("res-headshots").textContent = headshots;
      var m = Math.floor(elapsed / 60), s = Math.floor(elapsed % 60);
      document.getElementById("res-time").textContent = (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
      document.getElementById("res-cash").textContent = "+$" + cash;
      document.getElementById("res-xp").textContent = "+" + xp;
      var nextBtn = document.getElementById("btn-res-next");
      var showNext = victory && S.Missions.mode === "campaign" && S.Missions.current.id < 5;
      nextBtn.classList.toggle("hidden", !showNext);
      document.getElementById("screen-result").classList.remove("hidden");
    },

    openSettings: function (returnTo) {
      this.settingsReturnTo = returnTo || "menu";
      this.syncSettingsUI();
      if (returnTo === "pause") {
        document.getElementById("screen-pause").classList.add("hidden");
      } else {
        this.hideAllScreens();
      }
      document.getElementById("screen-settings").classList.remove("hidden");
    },

    closeSettings: function () {
      S.Save.save();
      document.getElementById("screen-settings").classList.add("hidden");
      if (this.settingsReturnTo === "pause") {
        document.getElementById("screen-pause").classList.remove("hidden");
      } else {
        this.showMenu();
      }
    },

    syncSettingsUI: function () {
      var s = S.Save.data.settings;
      var c = s.controls, g = s.graphics, a = s.audio, gp = s.gameplay;
      function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v; }
      function setChk(id, v) { var el = document.getElementById(id); if (el) el.checked = !!v; }
      function setTxt(id, v) { var el = document.getElementById(id); if (el) el.textContent = v; }

      setVal("set-preset", c.preset);
      setVal("set-firemode", c.fireMode);
      setVal("set-adsmode", c.adsMode);
      setVal("set-joymode", c.joyMode);
      setChk("set-leftfire", c.leftFire);
      setChk("set-lefthand", c.leftHanded);
      setChk("set-inverty", c.invertY);
      setChk("set-gyro", c.gyro);
      setChk("set-haptics", c.haptics);
      setVal("set-sens-hip", c.sensHip);   setTxt("val-sens-hip", c.sensHip);
      setVal("set-sens-ads", c.sensAds);   setTxt("val-sens-ads", c.sensAds);
      setVal("set-sens-4x", c.sens4x);     setTxt("val-sens-4x", c.sens4x);
      setVal("set-sens-8x", c.sens8x);     setTxt("val-sens-8x", c.sens8x);
      setVal("set-sens-gyro", c.sensGyro); setTxt("val-sens-gyro", c.sensGyro);
      setVal("set-smooth", c.smooth);      setTxt("val-smooth", c.smooth);
      setVal("set-aimassist", c.aimAssist);setTxt("val-aimassist", c.aimAssist);

      setVal("set-gfx-tier", g.tier);
      setVal("set-fps-cap", g.fpsCap);
      setVal("set-fov", g.fov); setTxt("val-fov", g.fov);
      setChk("set-rain", g.rain);
      setChk("set-showfps", g.showFps);

      setVal("set-vol-master", a.master); setTxt("val-vol-master", a.master);
      setVal("set-vol-sfx", a.sfx);       setTxt("val-vol-sfx", a.sfx);
      setVal("set-vol-music", a.music);   setTxt("val-vol-music", a.music);

      setVal("set-difficulty", gp.difficulty);
      setChk("set-autoreload", gp.autoReload);
      setVal("set-crosshair-style", gp.crosshairStyle);
      setVal("set-crosshair-color", gp.crosshairColor);
    },

    bindSettings: function () {
      var self = this;
      var tabs = ["controls", "graphics", "audio", "gameplay"];
      for (var i = 0; i < tabs.length; i++) {
        (function (t) {
          document.getElementById("tab-" + t).addEventListener("click", function () {
            S.Audio.playClick();
            for (var j = 0; j < tabs.length; j++) {
              document.getElementById("tab-" + tabs[j]).classList.toggle("active", tabs[j] === t);
              document.getElementById("panel-" + tabs[j]).classList.toggle("hidden", tabs[j] !== t);
            }
          });
        })(tabs[i]);
      }

      document.getElementById("btn-settings-back").addEventListener("click", function () {
        S.Audio.playClick();
        self.closeSettings();
      });
      document.getElementById("btn-edit-layout").addEventListener("click", function () {
        S.Audio.playClick();
        S.Input.openEditor();
      });

      function bindSelect(id, group, key, cb) {
        document.getElementById(id).addEventListener("change", function (e) {
          var v = e.target.value;
          S.Save.data.settings[group][key] = isNaN(Number(v)) ? v : Number(v);
          S.Save.save();
          if (cb) cb();
        });
      }
      function bindCheck(id, group, key, cb) {
        document.getElementById(id).addEventListener("change", function (e) {
          S.Save.data.settings[group][key] = !!e.target.checked;
          S.Save.save();
          if (cb) cb();
        });
      }
      function bindRange(id, valId, group, key, cb) {
        document.getElementById(id).addEventListener("input", function (e) {
          var v = Number(e.target.value);
          S.Save.data.settings[group][key] = v;
          document.getElementById(valId).textContent = v;
          S.Save.save();
          if (cb) cb();
        });
      }

      bindSelect("set-preset", "controls", "preset", function () { S.Input.applyLayout(); });
      bindSelect("set-firemode", "controls", "fireMode");
      bindSelect("set-adsmode", "controls", "adsMode");
      bindSelect("set-joymode", "controls", "joyMode", function () { S.Input.applyLayout(); });
      bindCheck("set-leftfire", "controls", "leftFire", function () { S.Input.applyLayout(); });
      bindCheck("set-lefthand", "controls", "leftHanded", function () { S.Input.applyLayout(); });
      bindCheck("set-inverty", "controls", "invertY");
      bindCheck("set-gyro", "controls", "gyro");
      bindCheck("set-haptics", "controls", "haptics");
      bindRange("set-sens-hip", "val-sens-hip", "controls", "sensHip");
      bindRange("set-sens-ads", "val-sens-ads", "controls", "sensAds");
      bindRange("set-sens-4x", "val-sens-4x", "controls", "sens4x");
      bindRange("set-sens-8x", "val-sens-8x", "controls", "sens8x");
      bindRange("set-sens-gyro", "val-sens-gyro", "controls", "sensGyro");
      bindRange("set-smooth", "val-smooth", "controls", "smooth");
      bindRange("set-aimassist", "val-aimassist", "controls", "aimAssist");

      bindSelect("set-gfx-tier", "graphics", "tier", function () { S.Core.applyGraphics(); });
      bindSelect("set-fps-cap", "graphics", "fpsCap");
      bindRange("set-fov", "val-fov", "graphics", "fov", function () { S.Core.applyGraphics(); });
      bindCheck("set-rain", "graphics", "rain", function () { S.Core.applyGraphics(); });
      bindCheck("set-showfps", "graphics", "showFps", function () { S.Core.applyGraphics(); });

      bindRange("set-vol-master", "val-vol-master", "audio", "master", function () { S.Audio.applyVolumes(); });
      bindRange("set-vol-sfx", "val-vol-sfx", "audio", "sfx", function () { S.Audio.applyVolumes(); });
      bindRange("set-vol-music", "val-vol-music", "audio", "music", function () { S.Audio.applyVolumes(); });

      bindSelect("set-difficulty", "gameplay", "difficulty");
      bindCheck("set-autoreload", "gameplay", "autoReload");
      bindSelect("set-crosshair-style", "gameplay", "crosshairStyle", function () { S.HUD.applyCrosshairStyle(); });
      bindSelect("set-crosshair-color", "gameplay", "crosshairColor", function () { S.HUD.applyCrosshairStyle(); });

      document.getElementById("btn-reset-save").addEventListener("click", function () {
        S.Save.resetProgress();
        S.Audio.playClick();
        self.showMenu();
      });
    },

    handleBack: function () {
      if (S.Input.editorMode) {
        S.Input.closeEditor();
      } else if (!document.getElementById("screen-settings").classList.contains("hidden")) {
        this.closeSettings();
      } else if (S.Core.state === "PLAY") {
        this.pauseGame();
      } else if (S.Core.state === "PAUSE") {
        this.resumeGame();
      } else if (S.Core.state === "RESULT") {
        this.showMenu();
      } else if (S.Core.state === "MENU") {
        var camp = !document.getElementById("screen-campaign").classList.contains("hidden");
        var brief = !document.getElementById("screen-briefing").classList.contains("hidden");
        var shop = !document.getElementById("screen-shop").classList.contains("hidden");
        if (brief) this.showCampaign();
        else if (camp || shop) this.showMenu();
        else if (window.AndroidBridge && window.AndroidBridge.exitApp) window.AndroidBridge.exitApp();
      }
    }
  };

  S.UI = UI;
})();
