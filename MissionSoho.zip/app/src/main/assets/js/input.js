(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var LOOK_RAD_PER_PX = 0.0022;
  var JOY_RADIUS = 64;

  var Input = {
    // Public state read every 60Hz logic tick
    moveX: 0,
    moveY: 0,
    sprintLock: false,
    lookDX: 0,
    lookDY: 0,
    smoothDX: 0,
    smoothDY: 0,
    firing: false,
    fireJustPressed: false,
    fireToggleOn: false,
    adsActive: false,
    jumpPressed: false,
    crouchToggled: false,
    interactPressed: false,

    // Multi-touch pointer tracking (up to 5 simultaneous fingers by pointerId)
    movePtrId: null,
    joyOriginX: 0,
    joyOriginY: 0,
    lookPtrs: {},     // pointerId -> {x, y}
    firePtrs: {},     // pointerId -> {x, y} (same finger can fire + rotate camera!)
    grenadePtrId: null,
    grenadeHoldTime: 0,
    slotSwipePtrId: null,
    slotSwipeX: 0,

    // Keyboard fallback
    keys: {},

    // Gyro
    gyroLastBeta: null,
    gyroLastGamma: null,

    // Layout editor state
    editorMode: false,
    editorSelected: null,
    editorBackup: null,
    edDragPtrId: null,
    edDragOffX: 0,
    edDragOffY: 0,

    init: function () {
      var self = this;

      // Prevent browser gestures / context menu
      window.addEventListener("contextmenu", function (e) { e.preventDefault(); });
      window.addEventListener("blur", function () { self.releaseAll(); });
      document.addEventListener("visibilitychange", function () {
        if (document.hidden) self.releaseAll();
      });

      this.bindMoveZone();
      this.bindLookZone();
      this.bindButtons();
      this.bindKeyboard();
      this.bindGyro();
      this.bindLayoutEditor();
      this.applyLayout();
    },

    releaseAll: function () {
      this.movePtrId = null;
      this.lookPtrs = {};
      this.firePtrs = {};
      this.grenadePtrId = null;
      this.slotSwipePtrId = null;
      this.moveX = 0;
      this.moveY = 0;
      this.sprintLock = false;
      this.firing = false;
      this.fireToggleOn = false;
      this.fireJustPressed = false;
      this.jumpPressed = false;
      this.interactPressed = false;
      this.lookDX = 0;
      this.lookDY = 0;
      this.keys = {};

      var jb = document.getElementById("joy-base");
      if (jb && S.Save.data.settings.controls.joyMode !== "fixed") jb.classList.add("hidden");
      var jk = document.getElementById("joy-knob");
      if (jk) { jk.style.left = "50%"; jk.style.top = "50%"; }
      var sl = document.getElementById("joy-sprint-lock");
      if (sl) sl.classList.remove("locked");
      var bf = document.getElementById("btn-fire");
      if (bf) bf.classList.remove("active");
      var bfl = document.getElementById("btn-fire-left");
      if (bfl) bfl.classList.remove("active");
      if (S.Weapons) S.Weapons.updateGrenadePreview(false);
    },

    getLookSensitivity: function () {
      var c = S.Save.data.settings.controls;
      if (this.adsActive && S.Weapons) {
        var w = S.Weapons.getCurrent();
        if (w.scope) {
          return (S.Weapons.scopeZoom === 8 ? c.sens8x : c.sens4x) / 100;
        }
        return c.sensAds / 100;
      }
      return c.sensHip / 100;
    },

    addLookDelta: function (dxPx, dyPx) {
      var sens = this.getLookSensitivity();
      var inv = S.Save.data.settings.controls.invertY ? -1 : 1;
      this.lookDX += dxPx * LOOK_RAD_PER_PX * sens;
      this.lookDY += dyPx * LOOK_RAD_PER_PX * sens * inv;
    },

    bindMoveZone: function () {
      var self = this;
      var zone = document.getElementById("zone-move");
      var base = document.getElementById("joy-base");
      var knob = document.getElementById("joy-knob");
      var slock = document.getElementById("joy-sprint-lock");

      function updateJoy(cx, cy) {
        var dx = cx - self.joyOriginX;
        var dy = cy - self.joyOriginY;
        var dist = Math.sqrt(dx * dx + dy * dy);
        var clamped = Math.min(dist, JOY_RADIUS);
        var nx = dist > 0.001 ? dx / dist : 0;
        var ny = dist > 0.001 ? dy / dist : 0;
        var norm = clamped / JOY_RADIUS;

        knob.style.left = (50 + (nx * clamped / (JOY_RADIUS * 2)) * 100) + "%";
        knob.style.top = (50 + (ny * clamped / (JOY_RADIUS * 2)) * 100) + "%";

        if (norm < 0.12) {
          self.moveX = 0;
          self.moveY = 0;
          self.sprintLock = false;
        } else {
          var curved = Math.pow((norm - 0.12) / 0.88, 1.3);
          self.moveX = nx * curved;
          self.moveY = -ny * curved; // forward is +moveY
          self.sprintLock = (norm > 0.92 && -ny > 0.65);
        }
        slock.classList.toggle("locked", self.sprintLock);
      }

      zone.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        if (self.movePtrId !== null) return;
        e.preventDefault();
        self.movePtrId = e.pointerId;
        try { zone.setPointerCapture(e.pointerId); } catch (err) {}

        var c = S.Save.data.settings.controls;
        if (c.joyMode === "fixed") {
          var fx = (c.leftHanded ? 0.84 : 0.16) * window.innerWidth;
          var fy = 0.72 * window.innerHeight;
          self.joyOriginX = fx;
          self.joyOriginY = fy;
        } else {
          self.joyOriginX = e.clientX;
          self.joyOriginY = e.clientY;
        }
        base.style.left = self.joyOriginX + "px";
        base.style.top = self.joyOriginY + "px";
        base.classList.remove("hidden");
        updateJoy(e.clientX, e.clientY);
      });

      zone.addEventListener("pointermove", function (e) {
        if (e.pointerId !== self.movePtrId) return;
        e.preventDefault();
        updateJoy(e.clientX, e.clientY);
      });

      function endMove(e) {
        if (e.pointerId !== self.movePtrId) return;
        self.movePtrId = null;
        self.moveX = 0;
        self.moveY = 0;
        self.sprintLock = false;
        slock.classList.remove("locked");
        knob.style.left = "50%";
        knob.style.top = "50%";
        if (S.Save.data.settings.controls.joyMode !== "fixed") {
          base.classList.add("hidden");
        }
      }
      zone.addEventListener("pointerup", endMove);
      zone.addEventListener("pointercancel", endMove);
    },

    bindLookZone: function () {
      var self = this;
      var zone = document.getElementById("zone-look");

      zone.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault();
        try { zone.setPointerCapture(e.pointerId); } catch (err) {}
        self.lookPtrs[e.pointerId] = { x: e.clientX, y: e.clientY };
      });

      zone.addEventListener("pointermove", function (e) {
        var p = self.lookPtrs[e.pointerId];
        if (!p) return;
        e.preventDefault();
        var dx = e.clientX - p.x;
        var dy = e.clientY - p.y;
        p.x = e.clientX;
        p.y = e.clientY;
        self.addLookDelta(dx, dy);
      });

      function endLook(e) {
        delete self.lookPtrs[e.pointerId];
      }
      zone.addEventListener("pointerup", endLook);
      zone.addEventListener("pointercancel", endLook);
    },

    bindFireButton: function (el) {
      var self = this;
      el.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault();
        e.stopPropagation();
        try { el.setPointerCapture(e.pointerId); } catch (err) {}
        self.firePtrs[e.pointerId] = { x: e.clientX, y: e.clientY };

        var fm = S.Save.data.settings.controls.fireMode;
        if (fm === "toggle") {
          self.fireToggleOn = !self.fireToggleOn;
          self.firing = self.fireToggleOn;
        } else {
          self.firing = true;
        }
        self.fireJustPressed = true;
        el.classList.add("active");
      });

      // CRITICAL: Same finger held on fire button also rotates camera when dragged!
      el.addEventListener("pointermove", function (e) {
        var p = self.firePtrs[e.pointerId];
        if (!p) return;
        e.preventDefault();
        var dx = e.clientX - p.x;
        var dy = e.clientY - p.y;
        p.x = e.clientX;
        p.y = e.clientY;
        self.addLookDelta(dx, dy);
      });

      function endFire(e) {
        if (!self.firePtrs[e.pointerId]) return;
        delete self.firePtrs[e.pointerId];
        var anyLeft = Object.keys(self.firePtrs).length > 0;
        if (S.Save.data.settings.controls.fireMode !== "toggle") {
          self.firing = anyLeft;
        }
        if (!anyLeft) el.classList.remove("active");
      }
      el.addEventListener("pointerup", endFire);
      el.addEventListener("pointercancel", endFire);
    },

    bindButtons: function () {
      var self = this;
      this.bindFireButton(document.getElementById("btn-fire"));
      this.bindFireButton(document.getElementById("btn-fire-left"));

      // ADS
      var btnAds = document.getElementById("btn-ads");
      btnAds.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        try { btnAds.setPointerCapture(e.pointerId); } catch (err) {}
        if (S.Save.data.settings.controls.adsMode === "hold") {
          self.adsActive = true;
        } else {
          self.adsActive = !self.adsActive;
        }
        btnAds.classList.toggle("active", self.adsActive);
      });
      function endAds() {
        if (S.Save.data.settings.controls.adsMode === "hold") {
          self.adsActive = false;
          btnAds.classList.remove("active");
        }
      }
      btnAds.addEventListener("pointerup", endAds);
      btnAds.addEventListener("pointercancel", endAds);

      // Sniper 4x / 8x zoom toggle
      document.getElementById("btn-scope-zoom").addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        S.Weapons.toggleScopeZoom();
      });

      // Reload
      document.getElementById("btn-reload").addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        S.Weapons.startReload();
      });

      // Jump
      document.getElementById("btn-jump").addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        self.jumpPressed = true;
      });

      // Crouch
      var btnCrouch = document.getElementById("btn-crouch");
      btnCrouch.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        self.crouchToggled = !self.crouchToggled;
        btnCrouch.classList.toggle("active", self.crouchToggled);
      });

      // Grenade: tap to quick-throw, hold to preview trajectory arc, release to throw
      var btnGren = document.getElementById("btn-grenade");
      btnGren.addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        try { btnGren.setPointerCapture(e.pointerId); } catch (err) {}
        self.grenadePtrId = e.pointerId;
        self.grenadeHoldTime = 0;
        btnGren.classList.add("active");
      });
      function endGren(e) {
        if (e.pointerId !== self.grenadePtrId) return;
        self.grenadePtrId = null;
        btnGren.classList.remove("active");
        S.Weapons.throwGrenade();
      }
      btnGren.addEventListener("pointerup", endGren);
      btnGren.addEventListener("pointercancel", function (e) {
        if (e.pointerId !== self.grenadePtrId) return;
        self.grenadePtrId = null;
        btnGren.classList.remove("active");
        S.Weapons.updateGrenadePreview(false);
      });

      // Interact
      document.getElementById("btn-interact").addEventListener("pointerdown", function (e) {
        if (self.editorMode || S.Core.state !== "PLAY") return;
        e.preventDefault(); e.stopPropagation();
        self.interactPressed = true;
      });

      // Pause
      document.getElementById("btn-pause").addEventListener("pointerdown", function (e) {
        if (self.editorMode) return;
        e.preventDefault(); e.stopPropagation();
        if (S.UI) S.UI.pauseGame();
      });

      // Weapon Slots 1-3 + Swipe to switch
      var slotsEl = document.getElementById("weapon-slots");
      for (var i = 0; i < 3; i++) {
        (function (idx) {
          document.getElementById("slot-" + idx).addEventListener("pointerdown", function (e) {
            if (self.editorMode || S.Core.state !== "PLAY") return;
            e.preventDefault(); e.stopPropagation();
            self.slotSwipePtrId = e.pointerId;
            self.slotSwipeX = e.clientX;
            S.Weapons.selectSlot(idx);
          });
        })(i);
      }
      slotsEl.addEventListener("pointerup", function (e) {
        if (e.pointerId !== self.slotSwipePtrId) return;
        var dx = e.clientX - self.slotSwipeX;
        self.slotSwipePtrId = null;
        if (Math.abs(dx) > 36) {
          S.Weapons.cycleWeapon(dx > 0 ? 1 : -1);
        }
      });
    },

    bindKeyboard: function () {
      var self = this;
      window.addEventListener("keydown", function (e) {
        self.keys[e.code] = true;
        if (S.Core.state !== "PLAY") return;
        if (e.code === "KeyR") S.Weapons.startReload();
        if (e.code === "KeyC") self.crouchToggled = !self.crouchToggled;
        if (e.code === "Space") self.jumpPressed = true;
        if (e.code === "KeyG") S.Weapons.throwGrenade();
        if (e.code === "KeyE") self.interactPressed = true;
        if (e.code === "Digit1") S.Weapons.selectSlot(0);
        if (e.code === "Digit2") S.Weapons.selectSlot(1);
        if (e.code === "Digit3") S.Weapons.selectSlot(2);
        if (e.code === "Escape" && S.UI) S.UI.pauseGame();
      });
      window.addEventListener("keyup", function (e) {
        self.keys[e.code] = false;
      });
    },

    bindGyro: function () {
      var self = this;
      window.addEventListener("deviceorientation", function (e) {
        if (!S.Save.data.settings.controls.gyro || S.Core.state !== "PLAY") {
          self.gyroLastBeta = null;
          self.gyroLastGamma = null;
          return;
        }
        if (e.beta === null || e.gamma === null) return;
        if (self.gyroLastBeta !== null) {
          var db = e.beta - self.gyroLastBeta;
          var dg = e.gamma - self.gyroLastGamma;
          if (Math.abs(db) < 25 && Math.abs(dg) < 25) {
            var sens = (S.Save.data.settings.controls.sensGyro / 100) * 0.012;
            self.lookDX += db * sens;
            self.lookDY += dg * sens;
          }
        }
        self.gyroLastBeta = e.beta;
        self.gyroLastGamma = e.gamma;
      });
    },

    // Apply saved HUD layout (% of screen, scale, alpha, left-hand mirror)
    applyLayout: function () {
      var c = S.Save.data.settings.controls;
      var lay = S.Save.getLayout(c.preset);
      var mirror = !!c.leftHanded;

      var zMove = document.getElementById("zone-move");
      var zLook = document.getElementById("zone-look");
      if (zMove && zLook) {
        zMove.style.left = mirror ? "52%" : "0";
        zLook.style.left = mirror ? "0" : "48%";
        zLook.style.right = "auto";
      }

      var flBtn = document.getElementById("btn-fire-left");
      if (flBtn) flBtn.classList.toggle("hidden", !c.leftFire && !this.editorMode);

      var els = document.querySelectorAll("[data-ctrl]");
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        var key = el.getAttribute("data-ctrl");
        var cfg = lay[key];
        if (!cfg) continue;
        var px = mirror ? (100 - cfg.x) : cfg.x;
        el.style.left = px + "%";
        el.style.top = cfg.y + "%";
        el.style.transform = "translate(-50%,-50%) scale(" + cfg.s + ")";
        el.style.opacity = cfg.a;
      }

      var jb = document.getElementById("joy-base");
      if (jb && c.joyMode === "fixed" && S.Core.state === "PLAY") {
        jb.style.left = (mirror ? 84 : 16) + "%";
        jb.style.top = "72%";
        jb.classList.remove("hidden");
      }
    },

    // HUD LAYOUT EDITOR
    bindLayoutEditor: function () {
      var self = this;
      var sizeSlider = document.getElementById("ed-size");
      var sizeVal = document.getElementById("ed-size-val");
      var alphaSlider = document.getElementById("ed-alpha");
      var alphaVal = document.getElementById("ed-alpha-val");
      var selName = document.getElementById("ed-selected-name");

      function selectCtrl(el) {
        var all = document.querySelectorAll("[data-ctrl]");
        for (var i = 0; i < all.length; i++) all[i].classList.remove("ed-selected");
        el.classList.add("ed-selected");
        self.editorSelected = el.getAttribute("data-ctrl");
        selName.textContent = self.editorSelected.toUpperCase();
        var cfg = S.Save.getLayout(S.Save.data.settings.controls.preset)[self.editorSelected];
        if (cfg) {
          sizeSlider.value = Math.round(cfg.s * 100);
          sizeVal.textContent = sizeSlider.value + "%";
          alphaSlider.value = Math.round(cfg.a * 100);
          alphaVal.textContent = alphaSlider.value + "%";
        }
      }

      var els = document.querySelectorAll("[data-ctrl]");
      for (var i = 0; i < els.length; i++) {
        (function (el) {
          el.addEventListener("pointerdown", function (e) {
            if (!self.editorMode) return;
            e.preventDefault(); e.stopPropagation();
            try { el.setPointerCapture(e.pointerId); } catch (err) {}
            selectCtrl(el);
            self.edDragPtrId = e.pointerId;
            var rect = el.getBoundingClientRect();
            self.edDragOffX = e.clientX - (rect.left + rect.width / 2);
            self.edDragOffY = e.clientY - (rect.top + rect.height / 2);
          });
          el.addEventListener("pointermove", function (e) {
            if (!self.editorMode || e.pointerId !== self.edDragPtrId) return;
            e.preventDefault();
            var c = S.Save.data.settings.controls;
            var lay = S.Save.getLayout(c.preset);
            var cfg = lay[self.editorSelected];
            if (!cfg) return;
            var pctX = ((e.clientX - self.edDragOffX) / window.innerWidth) * 100;
            var pctY = ((e.clientY - self.edDragOffY) / window.innerHeight) * 100;
            if (document.getElementById("ed-snap").checked) {
              pctX = Math.round(pctX / 2.5) * 2.5;
              pctY = Math.round(pctY / 2.5) * 2.5;
            }
            pctX = Math.max(5, Math.min(95, pctX));
            pctY = Math.max(8, Math.min(92, pctY));
            cfg.x = c.leftHanded ? (100 - pctX) : pctX;
            cfg.y = pctY;
            self.applyLayout();
          });
          function endDrag(e) {
            if (e.pointerId === self.edDragPtrId) self.edDragPtrId = null;
          }
          el.addEventListener("pointerup", endDrag);
          el.addEventListener("pointercancel", endDrag);
        })(els[i]);
      }

      sizeSlider.addEventListener("input", function () {
        sizeVal.textContent = sizeSlider.value + "%";
        if (!self.editorSelected) return;
        var cfg = S.Save.getLayout(S.Save.data.settings.controls.preset)[self.editorSelected];
        if (cfg) { cfg.s = Number(sizeSlider.value) / 100; self.applyLayout(); }
      });
      alphaSlider.addEventListener("input", function () {
        alphaVal.textContent = alphaSlider.value + "%";
        if (!self.editorSelected) return;
        var cfg = S.Save.getLayout(S.Save.data.settings.controls.preset)[self.editorSelected];
        if (cfg) { cfg.a = Number(alphaSlider.value) / 100; self.applyLayout(); }
      });

      document.getElementById("btn-ed-reset").addEventListener("click", function () {
        S.Save.resetLayout(S.Save.data.settings.controls.preset);
        self.applyLayout();
      });
      document.getElementById("btn-ed-cancel").addEventListener("click", function () {
        if (self.editorBackup) {
          S.Save.data.settings.layouts[S.Save.data.settings.controls.preset] = JSON.parse(self.editorBackup);
        }
        self.closeEditor();
      });
      document.getElementById("btn-ed-save").addEventListener("click", function () {
        S.Save.save();
        self.closeEditor();
      });
    },

    openEditor: function () {
      this.releaseAll();
      this.editorMode = true;
      this.editorSelected = null;
      var preset = S.Save.data.settings.controls.preset;
      this.editorBackup = JSON.stringify(S.Save.getLayout(preset));
      document.getElementById("screen-settings").classList.add("hidden");
      document.getElementById("screen-hud").classList.remove("hidden");
      document.getElementById("layout-editor-bar").classList.remove("hidden");
      document.getElementById("btn-interact").classList.remove("hidden");
      document.getElementById("btn-scope-zoom").classList.remove("hidden");
      this.applyLayout();
    },

    closeEditor: function () {
      this.editorMode = false;
      var all = document.querySelectorAll("[data-ctrl]");
      for (var i = 0; i < all.length; i++) all[i].classList.remove("ed-selected");
      document.getElementById("layout-editor-bar").classList.add("hidden");
      document.getElementById("btn-interact").classList.add("hidden");
      document.getElementById("btn-scope-zoom").classList.add("hidden");
      if (S.Core.state !== "PLAY" && S.Core.state !== "PAUSE") {
        document.getElementById("screen-hud").classList.add("hidden");
      }
      document.getElementById("screen-settings").classList.remove("hidden");
      this.applyLayout();
    },

    tick: function (dt) {
      // Keyboard movement fallback
      if (this.movePtrId === null) {
        var kx = (this.keys.KeyD ? 1 : 0) - (this.keys.KeyA ? 1 : 0);
        var ky = (this.keys.KeyW ? 1 : 0) - (this.keys.KeyS ? 1 : 0);
        if (kx || ky) {
          var l = Math.sqrt(kx * kx + ky * ky);
          this.moveX = kx / l;
          this.moveY = ky / l;
          this.sprintLock = !!this.keys.ShiftLeft;
        } else {
          this.moveX = 0;
          this.moveY = 0;
          this.sprintLock = false;
        }
      }

      // Grenade hold preview
      if (this.grenadePtrId !== null) {
        this.grenadeHoldTime += dt;
        if (this.grenadeHoldTime > 0.14 && S.Weapons) {
          S.Weapons.updateGrenadePreview(true);
        }
      }

      // Smoothing filter on look delta
      var sm = S.Save.data.settings.controls.smooth / 100; // 0..0.3
      var blend = 1 - sm * 2.2;
      this.smoothDX = this.smoothDX * (1 - blend) + this.lookDX * blend;
      this.smoothDY = this.smoothDY * (1 - blend) + this.lookDY * blend;
      this.lookDX = 0;
      this.lookDY = 0;
    },

    consumeFrameFlags: function () {
      this.fireJustPressed = false;
      this.jumpPressed = false;
      this.interactPressed = false;
    }
  };

  S.Input = Input;
})();
