(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var CAMPAIGN = [
    {
      id: 1, title: "OP 01: NEON ALLEY",
      desc: "Syndicate scouts have locked down Soho Main Street. Clear the district.",
      objective: "Eliminate 15 Hostiles",
      type: "kills", target: 15, cash: 250, xp: 300,
      spawnIdx: 0, timeLimit: 0
    },
    {
      id: 2, title: "OP 02: HOSTAGE CLUB",
      desc: "Three informants are held inside Soho Club. Breach the entrance and rescue all 3.",
      objective: "Rescue 3 Hostages inside Soho Club",
      type: "hostages", target: 3, cash: 400, xp: 450,
      spawnIdx: 0, timeLimit: 0
    },
    {
      id: 3, title: "OP 03: DATA HEIST",
      desc: "Extract 4 encrypted Syndicate intel drives across Soho before the purge timer hits zero.",
      objective: "Collect 4 Intel Drives (3:00)",
      type: "intel", target: 4, cash: 500, xp: 550,
      spawnIdx: 0, timeLimit: 180
    },
    {
      id: 4, title: "OP 04: HOLD THE PLAZA",
      desc: "Syndicate strike teams are converging on Soho Plaza. Survive all 5 waves.",
      objective: "Survive 5 Waves at Soho Plaza",
      type: "waves", target: 5, cash: 650, xp: 700,
      spawnIdx: 4, timeLimit: 0
    },
    {
      id: 5, title: "OP 05: THE KINGPIN",
      desc: "Eliminate the Syndicate Kingpin in the Plaza. Expect 3 armored combat phases.",
      objective: "Defeat the Syndicate Kingpin",
      type: "boss", target: 1, cash: 1000, xp: 1000,
      spawnIdx: 0, timeLimit: 0
    }
  ];

  var Missions = {
    CAMPAIGN: CAMPAIGN,
    mode: "campaign", // campaign, survival, training
    current: null,
    active: false,
    elapsed: 0,
    timeLeft: 0,
    kills: 0,
    headshots: 0,
    progress: 0,
    wave: 0,
    waveToKill: 0,
    spawnTimer: 0,
    interactables: [],
    waypoint: null,
    checkpointReached: false,
    tutStep: 0,
    tutTimer: 0,
    trainingHits: 0,

    clearInteractables: function () {
      for (var i = 0; i < this.interactables.length; i++) {
        S.Core.scene.remove(this.interactables[i].mesh);
      }
      this.interactables.length = 0;
    },

    addInteractable: function (label, x, y, z, color) {
      var g = new THREE.Group();
      var box = new THREE.Mesh(
        new THREE.BoxGeometry(0.6, 1.2, 0.6),
        new THREE.MeshBasicMaterial({ color: color })
      );
      box.position.y = 0.7;
      g.add(box);
      var beacon = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.08, 8, 6),
        new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.4 })
      );
      beacon.position.y = 4.5;
      g.add(beacon);
      g.position.set(x, y, z);
      S.Core.scene.add(g);
      this.interactables.push({ label: label, x: x, y: y, z: z, mesh: g, done: false });
    },

    startCampaign: function (missionId) {
      var m = CAMPAIGN[missionId - 1] || CAMPAIGN[0];
      this.mode = "campaign";
      this.current = m;
      this.beginRun(false);
    },

    startSurvival: function () {
      this.mode = "survival";
      this.current = {
        id: 0, title: "SURVIVAL OPS", objective: "Survive Endless Waves",
        type: "survival", target: 999, cash: 0, xp: 0, spawnIdx: 4, timeLimit: 0
      };
      this.beginRun(false);
    },

    startTraining: function () {
      this.mode = "training";
      this.current = {
        id: 0, title: "TRAINING RANGE", objective: "Practice Weapons & Controls (Swipe Slots for All 5 Guns)",
        type: "training", target: 999, cash: 0, xp: 0, spawnIdx: 0, timeLimit: 0
      };
      this.beginRun(true);
    },

    beginRun: function (isTraining) {
      this.clearInteractables();
      S.Enemies.clearAll();
      S.World.resetPickups();
      S.World.setupTrainingTargets(isTraining);
      S.Weapons.resetLoadout(isTraining);

      var sp = S.World.playerSpawns[this.current.spawnIdx || 0];
      S.Player.spawn(sp.x, sp.y, sp.z, 0);

      this.active = true;
      this.elapsed = 0;
      this.timeLeft = this.current.timeLimit || 0;
      this.kills = 0;
      this.headshots = 0;
      this.progress = 0;
      this.wave = 1;
      this.waveToKill = 0;
      this.spawnTimer = 0.5;
      this.waypoint = null;
      this.checkpointReached = false;
      this.trainingHits = 0;
      this.tutStep = (!S.Save.data.progress.tutorialDone && (this.current.id === 1 || isTraining)) ? 1 : 0;
      this.tutTimer = 0;

      // Setup mission-specific entities
      var t = this.current.type;
      if (t === "kills") {
        this.spawnWaveEnemies(7, ["grunt", "grunt", "shotgunner"]);
        this.waypoint = { x: 0, y: 2, z: -20 };
      } else if (t === "hostages") {
        this.addInteractable("RESCUE", 31, 0, -28, 0x00ff99);
        this.addInteractable("RESCUE", 48, 0, -19, 0x00ff99);
        this.addInteractable("RESCUE", 31, 0, -10, 0x00ff99);
        this.spawnWaveEnemies(10, ["grunt", "shotgunner", "heavy"], true);
      } else if (t === "intel") {
        this.addInteractable("HACK INTEL", -44, 0, 32, 0x00f0ff);
        this.addInteractable("HACK INTEL", 42, 0, 44, 0x00f0ff);
        this.addInteractable("HACK INTEL", 40, 0, -19, 0x00f0ff);
        this.addInteractable("HACK INTEL", -16, 4.2, 28, 0x00f0ff);
        this.spawnWaveEnemies(10, ["grunt", "shotgunner", "sniper"]);
      } else if (t === "waves") {
        this.startWave(1);
      } else if (t === "boss") {
        S.Enemies.spawn("boss", 0, 0, -24);
        this.spawnWaveEnemies(5, ["grunt", "sniper", "heavy"]);
        this.waypoint = { x: 0, y: 2.5, z: -24 };
      } else if (t === "survival") {
        this.startWave(1);
      }

      if (S.HUD) S.HUD.showBanner(this.current.title);
      this.updateObjectiveUI();
    },

    startWave: function (w) {
      this.wave = w;
      var count = 5 + w * 2;
      this.waveToKill = count;
      var pool = w === 1 ? ["grunt", "shotgunner"] : (w < 4 ? ["grunt", "shotgunner", "sniper"] : ["grunt", "shotgunner", "sniper", "heavy"]);
      this.spawnWaveEnemies(Math.min(count, 10), pool);
      if (S.HUD) S.HUD.showBanner("WAVE " + w + " INCOMING!");
      if (this.mode === "survival" && w % 2 === 0) {
        S.World.spawnAirdrop(0, -12);
        S.HUD.showBanner("WAVE " + w + " — AIRDROP AT SOHO PLAZA!");
      }
      if (this.mode === "campaign" && w === 3 && !this.checkpointReached) {
        this.checkpointReached = true;
        S.Player.hp = S.Player.maxHp;
        S.Player.armor = S.Player.maxArmor;
        S.HUD.showBanner("CHECKPOINT REACHED — HEALTH & ARMOR RESTORED");
      }
    },

    spawnWaveEnemies: function (count, types, preferClub) {
      var spawns = S.World.enemySpawns;
      for (var i = 0; i < count; i++) {
        if (S.Enemies.activeCount >= 18) break;
        var sp;
        if (preferClub && i < 5) {
          sp = spawns[30 + (i % 5)];
        } else {
          // Pick spawn at least 18m from player
          for (var tries = 0; tries < 8; tries++) {
            var cand = spawns[Math.floor(Math.random() * spawns.length)];
            var d = Math.hypot(cand.x - S.Player.pos.x, cand.z - S.Player.pos.z);
            if (d > 18) { sp = cand; break; }
          }
          if (!sp) sp = spawns[i % spawns.length];
        }
        var t = types[Math.floor(Math.random() * types.length)];
        S.Enemies.spawn(t, sp.x, sp.y || 0, sp.z);
      }
    },

    onBossPhase: function (phase, boss) {
      this.spawnWaveEnemies(phase === 2 ? 4 : 6, ["shotgunner", "heavy", "sniper"]);
      S.FX.spawnExplosion(boss.x, boss.y + 1, boss.z);
    },

    onTrainingTargetHit: function () {
      this.trainingHits++;
      this.updateObjectiveUI();
    },

    onEnemyKilled: function (enemy, isHead) {
      if (!this.active) return;
      this.kills++;
      if (isHead) this.headshots++;

      var t = this.current.type;
      if (t === "kills") {
        this.progress = this.kills;
        if (this.progress === 8 && !this.checkpointReached) {
          this.checkpointReached = true;
          S.HUD.showBanner("CHECKPOINT — HALFWAY CLEAR!");
        }
        if (this.progress >= this.current.target) {
          this.finish(true);
          return;
        }
      } else if (t === "waves" || t === "survival") {
        this.waveToKill = Math.max(0, this.waveToKill - 1);
        if (this.waveToKill <= 0) {
          if (t === "waves" && this.wave >= this.current.target) {
            this.finish(true);
            return;
          }
          this.startWave(this.wave + 1);
        }
      } else if (t === "boss" && enemy.type === "boss") {
        this.progress = 1;
        this.finish(true);
        return;
      }
      this.updateObjectiveUI();
    },

    onPlayerDeath: function () {
      if (!this.active) return;
      this.finish(false);
    },

    finish: function (victory) {
      this.active = false;
      var cash = this.kills * 25;
      var xp = this.kills * 30 + this.headshots * 15;
      var stars = 0;

      if (victory && this.mode === "campaign") {
        cash += this.current.cash;
        xp += this.current.xp;
        stars = 1;
        if (S.Player.hp >= 40) stars = 2;
        if (S.Player.hp >= 70 && this.headshots >= 3) stars = 3;
        var p = S.Save.data.progress;
        if (stars > (p.stars[this.current.id] || 0)) p.stars[this.current.id] = stars;
        if (this.current.id >= p.unlockedMission && this.current.id < 5) {
          p.unlockedMission = this.current.id + 1;
        }
        p.tutorialDone = true;
      } else if (this.mode === "survival") {
        var p2 = S.Save.data.progress;
        if (this.wave > p2.bestSurvivalWave) p2.bestSurvivalWave = this.wave;
        stars = this.wave >= 5 ? 3 : (this.wave >= 3 ? 2 : 1);
      }

      S.Save.addReward(cash, xp);
      if (S.UI) S.UI.showResult(victory, stars, this.kills, this.headshots, this.elapsed, cash, xp);
    },

    updateObjectiveUI: function () {
      var el = document.getElementById("objective-text");
      if (!el || !this.current) return;
      var t = this.current.type;
      if (t === "kills") el.textContent = "ELIMINATE HOSTILES: " + this.progress + " / " + this.current.target;
      else if (t === "hostages") el.textContent = "RESCUE HOSTAGES: " + this.progress + " / " + this.current.target;
      else if (t === "intel") el.textContent = "EXTRACT INTEL: " + this.progress + " / " + this.current.target;
      else if (t === "waves") el.textContent = "WAVE " + this.wave + " / " + this.current.target + " · LEFT: " + this.waveToKill;
      else if (t === "boss") el.textContent = "DEFEAT THE SYNDICATE KINGPIN";
      else if (t === "survival") el.textContent = "SURVIVAL WAVE " + this.wave + " · LEFT: " + this.waveToKill;
      else if (t === "training") el.textContent = "TRAINING RANGE · TARGETS HIT: " + this.trainingHits;
    },

    update: function (dt, player, input) {
      if (!this.active) return;
      this.elapsed += dt;

      // Timer for timed missions (Data Heist)
      var timerEl = document.getElementById("objective-timer");
      if (this.current.timeLimit > 0) {
        this.timeLeft = Math.max(0, this.timeLeft - dt);
        if (timerEl) {
          var m = Math.floor(this.timeLeft / 60);
          var s = Math.floor(this.timeLeft % 60);
          timerEl.textContent = (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
          timerEl.classList.remove("hidden");
        }
        if (this.timeLeft <= 0) {
          this.finish(false);
          return;
        }
      } else if (timerEl) {
        timerEl.classList.add("hidden");
      }

      // Guided tutorial hints on first run
      if (this.tutStep > 0) {
        this.tutTimer += dt;
        if (this.tutStep === 1 && this.tutTimer > 1.2) {
          S.HUD.showBanner("LEFT THUMB: MOVE · RIGHT SIDE: AIM");
          this.tutStep = 2; this.tutTimer = 0;
        } else if (this.tutStep === 2 && this.tutTimer > 5.0) {
          S.HUD.showBanner("DRAG FIRE BUTTON TO SHOOT & AIM AT ONCE!");
          this.tutStep = 3; this.tutTimer = 0;
        } else if (this.tutStep === 3 && this.tutTimer > 5.5) {
          S.HUD.showBanner("HOLD FRAG FOR ARC · USE ADS FOR PRECISION");
          this.tutStep = 0;
        }
      }

      // Continuous reinforcement spawner for kills/waves/survival/intel
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0 && this.mode !== "training") {
        this.spawnTimer = 3.2;
        var t = this.current.type;
        if (t === "kills" && S.Enemies.activeCount < 8 && (this.kills + S.Enemies.activeCount) < this.current.target) {
          this.spawnWaveEnemies(3, ["grunt", "shotgunner", "sniper"]);
        } else if ((t === "waves" || t === "survival") && S.Enemies.activeCount < Math.min(12, this.waveToKill)) {
          this.spawnWaveEnemies(Math.min(4, this.waveToKill - S.Enemies.activeCount), ["grunt", "shotgunner", "sniper", "heavy"]);
        } else if ((t === "intel" || t === "hostages") && S.Enemies.activeCount < 6) {
          this.spawnWaveEnemies(2, ["grunt", "shotgunner"]);
        }
      }

      // Interactables (Hostages / Intel Drives) + 3D Waypoint selection
      var nearItem = null;
      var bestW = null, bestWD = 1e9;
      for (var i = 0; i < this.interactables.length; i++) {
        var it = this.interactables[i];
        if (it.done) continue;
        it.mesh.rotation.y += dt * 1.5;
        var d = Math.hypot(it.x - player.pos.x, it.z - player.pos.z);
        if (d < bestWD) { bestWD = d; bestW = it; }
        if (d < 3.0 && Math.abs(it.y - player.pos.y) < 2.0) nearItem = it;
      }

      var btnInt = document.getElementById("btn-interact");
      var lblInt = document.getElementById("interact-label");
      if (nearItem) {
        if (btnInt) btnInt.classList.remove("hidden");
        if (lblInt) lblInt.textContent = nearItem.label;
        if (input.interactPressed) {
          nearItem.done = true;
          nearItem.mesh.visible = false;
          this.progress++;
          S.Audio.playPickup();
          S.Save.vibrate(40);
          S.HUD.showBanner(nearItem.label + " COMPLETE (" + this.progress + "/" + this.current.target + ")");
          this.updateObjectiveUI();
          if (this.progress >= this.current.target) {
            this.finish(true);
            return;
          }
        }
      } else if (btnInt && !S.Input.editorMode) {
        btnInt.classList.add("hidden");
      }

      if (bestW) {
        this.waypoint = { x: bestW.x, y: bestW.y + 1.8, z: bestW.z };
      } else if (this.current.type === "boss") {
        for (var b = 0; b < S.Enemies.pool.length; b++) {
          var be = S.Enemies.pool[b];
          if (be.active && be.type === "boss") {
            this.waypoint = { x: be.x, y: be.y + 2.6, z: be.z };
            break;
          }
        }
      }
    }
  };

  S.Missions = Missions;
})();
