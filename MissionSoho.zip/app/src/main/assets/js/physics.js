(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var CELL = 8;
  var Physics = {
    boxes: [],
    grid: {},
    worldHalf: 110,
    checkedStamp: 0,

    clear: function () {
      this.boxes.length = 0;
      this.grid = {};
      this.checkedStamp = 0;
    },

    addBox: function (minX, minY, minZ, maxX, maxY, maxZ, tag) {
      var b = {
        id: this.boxes.length,
        minX: minX, minY: minY, minZ: minZ,
        maxX: maxX, maxY: maxY, maxZ: maxZ,
        tag: tag || "solid",
        _st: 0
      };
      this.boxes.push(b);
      var x0 = Math.floor(minX / CELL), x1 = Math.floor(maxX / CELL);
      var z0 = Math.floor(minZ / CELL), z1 = Math.floor(maxZ / CELL);
      for (var gx = x0; gx <= x1; gx++) {
        for (var gz = z0; gz <= z1; gz++) {
          var key = gx + "," + gz;
          if (!this.grid[key]) this.grid[key] = [];
          this.grid[key].push(b);
        }
      }
      return b;
    },

    // Resolve capsule (feet at pos.y, radius r, height h) vs static AABBs
    resolveCapsule: function (pos, vel, r, h, stepH, outInfo) {
      outInfo.grounded = false;
      var stamp = ++this.checkedStamp;
      var gx0 = Math.floor((pos.x - r - 0.5) / CELL);
      var gx1 = Math.floor((pos.x + r + 0.5) / CELL);
      var gz0 = Math.floor((pos.z - r - 0.5) / CELL);
      var gz1 = Math.floor((pos.z + r + 0.5) / CELL);

      // Floor y=0
      if (pos.y <= 0) {
        pos.y = 0;
        if (vel.y < 0) vel.y = 0;
        outInfo.grounded = true;
      }

      for (var gx = gx0; gx <= gx1; gx++) {
        for (var gz = gz0; gz <= gz1; gz++) {
          var cell = this.grid[gx + "," + gz];
          if (!cell) continue;
          for (var i = 0; i < cell.length; i++) {
            var b = cell[i];
            if (b._st === stamp) continue;
            b._st = stamp;

            // Vertical overlap check
            if (pos.y + h <= b.minY || pos.y >= b.maxY + 0.05) continue;

            // Closest point in XZ
            var cx = pos.x < b.minX ? b.minX : (pos.x > b.maxX ? b.maxX : pos.x);
            var cz = pos.z < b.minZ ? b.minZ : (pos.z > b.maxZ ? b.maxZ : pos.z);
            var dx = pos.x - cx;
            var dz = pos.z - cz;
            var d2 = dx * dx + dz * dz;
            if (d2 >= r * r) continue;

            // Step-up or landing on top
            var climb = b.maxY - pos.y;
            if (climb >= -0.05 && climb <= stepH && vel.y <= 1.0) {
              pos.y = b.maxY;
              if (vel.y < 0) vel.y = 0;
              outInfo.grounded = true;
              continue;
            }
            // Head bump
            if (vel.y > 0 && (pos.y + h - b.minY) < 0.35) {
              pos.y = b.minY - h;
              vel.y = 0;
              continue;
            }

            // Horizontal push-out
            if (d2 > 0.000001) {
              var d = Math.sqrt(d2);
              var push = r - d;
              pos.x += (dx / d) * push;
              pos.z += (dz / d) * push;
            } else {
              // Inside box XZ: push out along shallowest axis
              var ox1 = Math.abs(pos.x - b.minX);
              var ox2 = Math.abs(b.maxX - pos.x);
              var oz1 = Math.abs(pos.z - b.minZ);
              var oz2 = Math.abs(b.maxZ - pos.z);
              var m = Math.min(ox1, ox2, oz1, oz2);
              if (m === ox1) pos.x = b.minX - r;
              else if (m === ox2) pos.x = b.maxX + r;
              else if (m === oz1) pos.z = b.minZ - r;
              else pos.z = b.maxZ + r;
            }
          }
        }
      }

      // World bounds & kill-plane safety
      var lim = this.worldHalf - 2;
      if (pos.x < -lim) pos.x = -lim;
      if (pos.x > lim) pos.x = lim;
      if (pos.z < -lim) pos.z = -lim;
      if (pos.z > lim) pos.z = lim;
      if (pos.y < -15) {
        pos.set(0, 2, 0);
        vel.set(0, 0, 0);
      }
    },

    // Raycast against static world AABBs (DDA-free grid march, fast and exact)
    raycastWorld: function (ox, oy, oz, dx, dy, dz, maxDist, outHit) {
      var bestT = maxDist;
      var hit = false;
      var stamp = ++this.checkedStamp;

      // Ground plane y=0 check
      if (dy < -0.0001 && oy > 0) {
        var tg = -oy / dy;
        if (tg > 0 && tg < bestT) {
          bestT = tg;
          hit = true;
        }
      }

      var invX = Math.abs(dx) > 1e-6 ? 1 / dx : 1e9;
      var invY = Math.abs(dy) > 1e-6 ? 1 / dy : 1e9;
      var invZ = Math.abs(dz) > 1e-6 ? 1 / dz : 1e9;

      var steps = Math.ceil(maxDist / 4) + 1;
      var stepLen = maxDist / steps;
      for (var s = 0; s <= steps; s++) {
        var dist = s * stepLen;
        if (dist > bestT + CELL) break;
        var px = ox + dx * dist;
        var pz = oz + dz * dist;
        var gx = Math.floor(px / CELL);
        var gz = Math.floor(pz / CELL);
        for (var ix = -1; ix <= 1; ix++) {
          for (var iz = -1; iz <= 1; iz++) {
            var cell = this.grid[(gx + ix) + "," + (gz + iz)];
            if (!cell) continue;
            for (var i = 0; i < cell.length; i++) {
              var b = cell[i];
              if (b._st === stamp) continue;
              b._st = stamp;

              var t1 = (b.minX - ox) * invX;
              var t2 = (b.maxX - ox) * invX;
              var tmin = Math.min(t1, t2);
              var tmax = Math.max(t1, t2);

              var t3 = (b.minY - oy) * invY;
              var t4 = (b.maxY - oy) * invY;
              tmin = Math.max(tmin, Math.min(t3, t4));
              tmax = Math.min(tmax, Math.max(t3, t4));

              var t5 = (b.minZ - oz) * invZ;
              var t6 = (b.maxZ - oz) * invZ;
              tmin = Math.max(tmin, Math.min(t5, t6));
              tmax = Math.min(tmax, Math.max(t5, t6));

              if (tmax >= 0 && tmin <= tmax && tmin >= 0 && tmin < bestT) {
                bestT = tmin;
                hit = true;
              }
            }
          }
        }
      }

      if (outHit) {
        outHit.hit = hit;
        outHit.dist = bestT;
        outHit.x = ox + dx * bestT;
        outHit.y = oy + dy * bestT;
        outHit.z = oz + dz * bestT;
      }
      return hit ? bestT : maxDist;
    },

    hasLOS: function (ax, ay, az, bx, by, bz) {
      var dx = bx - ax, dy = by - ay, dz = bz - az;
      var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < 0.1) return true;
      var hitDist = this.raycastWorld(ax, ay, az, dx / dist, dy / dist, dz / dist, dist);
      return hitDist >= dist - 0.15;
    },

    pointBlockedXZ: function (x, z, yCheck) {
      var yc = yCheck !== undefined ? yCheck : 1.0;
      var cell = this.grid[Math.floor(x / CELL) + "," + Math.floor(z / CELL)];
      if (!cell) return false;
      for (var i = 0; i < cell.length; i++) {
        var b = cell[i];
        if (x >= b.minX - 0.45 && x <= b.maxX + 0.45 &&
            z >= b.minZ - 0.45 && z <= b.maxZ + 0.45 &&
            yc >= b.minY && yc <= b.maxY) {
          return true;
        }
      }
      return false;
    }
  };

  S.Physics = Physics;
})();
