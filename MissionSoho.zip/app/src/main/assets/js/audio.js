(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var AudioSys = {
    ctx: null,
    masterGain: null,
    sfxGain: null,
    musicGain: null,
    noiseBuf: null,
    musicTimer: null,
    musicStep: 0,
    unlocked: false,

    init: function () {
      var self = this;
      var unlock = function () {
        self.unlock();
      };
      window.addEventListener("pointerdown", unlock, { passive: true });
      window.addEventListener("touchstart", unlock, { passive: true });
      window.addEventListener("keydown", unlock, { passive: true });
      document.addEventListener("visibilitychange", function () {
        if (document.hidden) self.suspend();
        else self.resume();
      });
    },

    unlock: function () {
      if (!this.ctx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.masterGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();
        this.musicGain = this.ctx.createGain();
        this.sfxGain.connect(this.masterGain);
        this.musicGain.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);
        this.createNoiseBuffer();
        this.applyVolumes();
        this.startMusic();
      }
      if (this.ctx.state === "suspended") {
        this.ctx.resume().catch(function () {});
      }
      this.unlocked = true;
    },

    createNoiseBuffer: function () {
      var sr = this.ctx.sampleRate;
      var len = Math.floor(sr * 1.0);
      var buf = this.ctx.createBuffer(1, len, sr);
      var ch = buf.getChannelData(0);
      for (var i = 0; i < len; i++) {
        ch[i] = Math.random() * 2 - 1;
      }
      this.noiseBuf = buf;
    },

    applyVolumes: function () {
      if (!this.ctx) return;
      var a = S.Save.data.settings.audio;
      this.masterGain.gain.value = (a.master / 100) * 0.9;
      this.sfxGain.gain.value = a.sfx / 100;
      this.musicGain.gain.value = (a.music / 100) * 0.35;
    },

    suspend: function () {
      if (this.ctx && this.ctx.state === "running") {
        this.ctx.suspend().catch(function () {});
      }
    },

    resume: function () {
      if (this.ctx && this.ctx.state === "suspended" && this.unlocked) {
        this.ctx.resume().catch(function () {});
      }
    },

    startMusic: function () {
      if (this.musicTimer) return;
      var self = this;
      var notes = [55, 55, 65.4, 55, 73.4, 65.4, 49, 55];
      this.musicTimer = setInterval(function () {
        if (!self.ctx || self.ctx.state !== "running") return;
        if (S.Save.data.settings.audio.music <= 0) return;
        var now = self.ctx.currentTime;
        var osc = self.ctx.createOscillator();
        var g = self.ctx.createGain();
        osc.type = "sawtooth";
        var f = notes[self.musicStep % notes.length];
        self.musicStep++;
        osc.frequency.setValueAtTime(f, now);
        g.gain.setValueAtTime(0.18, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
        var filt = self.ctx.createBiquadFilter();
        filt.type = "lowpass";
        filt.frequency.value = S.Core && S.Core.state === "PLAY" ? 420 : 260;
        osc.connect(filt);
        filt.connect(g);
        g.connect(self.musicGain);
        osc.start(now);
        osc.stop(now + 0.25);
      }, 260);
    },

    playShot: function (weaponId) {
      if (!this.ctx || this.ctx.state !== "running") return;
      var now = this.ctx.currentTime;
      var dur = weaponId === "shotgun" ? 0.22 : (weaponId === "sniper" ? 0.28 : (weaponId === "smg" ? 0.08 : 0.13));
      var pitch = weaponId === "sniper" ? 110 : (weaponId === "shotgun" ? 90 : (weaponId === "smg" ? 240 : (weaponId === "pistol" ? 210 : 165)));

      // Noise burst
      var n = this.ctx.createBufferSource();
      n.buffer = this.noiseBuf;
      var filt = this.ctx.createBiquadFilter();
      filt.type = "bandpass";
      filt.frequency.setValueAtTime(weaponId === "sniper" ? 900 : 1500, now);
      var ng = this.ctx.createGain();
      ng.gain.setValueAtTime(weaponId === "shotgun" ? 0.65 : 0.42, now);
      ng.gain.exponentialRampToValueAtTime(0.001, now + dur);
      n.connect(filt);
      filt.connect(ng);
      ng.connect(this.sfxGain);
      n.start(now);
      n.stop(now + dur);

      // Punch oscillator
      var o = this.ctx.createOscillator();
      var og = this.ctx.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(pitch, now);
      o.frequency.exponentialRampToValueAtTime(38, now + dur * 0.8);
      og.gain.setValueAtTime(0.45, now);
      og.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.85);
      o.connect(og);
      og.connect(this.sfxGain);
      o.start(now);
      o.stop(now + dur);
    },

    playExplosion: function () {
      if (!this.ctx || this.ctx.state !== "running") return;
      var now = this.ctx.currentTime;
      var n = this.ctx.createBufferSource();
      n.buffer = this.noiseBuf;
      var f = this.ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.setValueAtTime(520, now);
      f.frequency.exponentialRampToValueAtTime(60, now + 0.65);
      var g = this.ctx.createGain();
      g.gain.setValueAtTime(0.95, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      n.connect(f);
      f.connect(g);
      g.connect(this.sfxGain);
      n.start(now);
      n.stop(now + 0.72);
    },

    playTone: function (freq, dur, type, vol, freqEnd) {
      if (!this.ctx || this.ctx.state !== "running") return;
      var now = this.ctx.currentTime;
      var o = this.ctx.createOscillator();
      var g = this.ctx.createGain();
      o.type = type || "sine";
      o.frequency.setValueAtTime(freq, now);
      if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, now + dur);
      g.gain.setValueAtTime(vol || 0.2, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + dur);
      o.connect(g);
      g.connect(this.sfxGain);
      o.start(now);
      o.stop(now + dur + 0.01);
    },

    playHit: function (head) {
      this.playTone(head ? 1350 : 720, head ? 0.09 : 0.05, "triangle", head ? 0.35 : 0.22, head ? 1800 : 500);
    },
    playReload: function () { this.playTone(320, 0.1, "square", 0.15, 520); },
    playEmpty: function () { this.playTone(180, 0.04, "square", 0.12, 120); },
    playPickup: function () { this.playTone(580, 0.16, "sine", 0.24, 980); },
    playHurt: function () { this.playTone(130, 0.14, "sawtooth", 0.3, 60); },
    playStep: function () { this.playTone(95, 0.04, "triangle", 0.08, 50); },
    playClick: function () { this.playTone(620, 0.04, "sine", 0.14, 420); }
  };

  S.Audio = AudioSys;
})();
