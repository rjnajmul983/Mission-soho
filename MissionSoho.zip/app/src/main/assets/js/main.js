(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var accum = 0;
  var lastTime = 0;
  var lastRender = 0;

  function setLoad(pct, text) {
    var b = document.getElementById("loading-bar");
    var t = document.getElementById("loading-status");
    if (b) b.style.width = pct + "%";
    if (t) t.textContent = text;
  }

  function stepLogic(dt) {
    S.Input.tick(dt);
    S.Player.update(dt, S.Input);
    S.Weapons.update(dt, S.Player, S.Input);
    S.Enemies.update(dt, S.Player);
    S.Missions.update(dt, S.Player, S.Input);
    S.World.update(dt);
    S.FX.update(dt, S.Core.camera.position);
    S.HUD.update(dt);
    S.Input.consumeFrameFlags();
  }

  function frame(now) {
    requestAnimationFrame(frame);
    if (!lastTime) { lastTime = now; lastRender = now; return; }

    var cap = S.Save.data.settings.graphics.fpsCap || 60;
    var minFrameMs = cap <= 30 ? 32 : 0;
    if (minFrameMs > 0 && (now - lastRender) < minFrameMs) return;

    var dt = Math.min(S.Core.MAX_DT, Math.max(0, (now - lastTime) / 1000));
    lastTime = now;
    lastRender = now;

    S.Core.trackFps(dt);

    if (S.Core.state === "PLAY") {
      accum += dt;
      var fixed = S.Core.FIXED_DT;
      var steps = 0;
      while (accum >= fixed && steps < 4) {
        stepLogic(fixed);
        accum -= fixed;
        steps++;
      }
      S.Core.renderer.render(S.Core.scene, S.Core.camera);
    } else if (S.Core.state === "MENU" || S.Core.state === "PAUSE") {
      // Slow cinematic neon city orbit in background
      var t = now * 0.00018;
      S.Core.camera.position.set(Math.sin(t) * 28, 13, -20 + Math.cos(t) * 28);
      S.Core.camera.lookAt(0, 4, -20);
      S.World.update(dt);
      S.FX.update(dt, S.Core.camera.position);
      S.Core.renderer.render(S.Core.scene, S.Core.camera);
    }
  }

  function boot() {
    S.Core.setState("LOADING");
    var steps = [
      [15, "INITIALIZING WEBGL ENGINE...", function () { S.Core.init(); }],
      [30, "SYNTHESIZING AUDIO ENGINE...", function () { S.Audio.init(); }],
      [45, "ALLOCATING FX POOLS...", function () { S.FX.init(); }],
      [60, "CONSTRUCTING SOHO DISTRICT...", function () { S.World.init(); }],
      [74, "BUILDING 2M NAV GRID...", function () { S.AI.init(); }],
      [84, "ARMING WEAPONS & OPERATIVE...", function () { S.Player.init(); S.Weapons.init(); S.Enemies.init(); }],
      [94, "WIRING TOUCH CONTROLS & HUD...", function () { S.Input.init(); S.HUD.init(); S.UI.init(); }],
      [100, "READY FOR DEPLOYMENT", function () { S.UI.showMenu(); requestAnimationFrame(frame); }]
    ];

    var idx = 0;
    function next() {
      if (idx >= steps.length) return;
      var st = steps[idx++];
      setLoad(st[0], st[1]);
      setTimeout(function () {
        st[2]();
        next();
      }, 30);
    }
    next();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
