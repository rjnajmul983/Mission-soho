(function () {
  "use strict";
  var S = window.SOHO = window.SOHO || {};

  var MAX_PITCH = 85 * Math.PI / 180;

  var Player = {
    pos: null,
    vel: null,
    yaw: 0,
    pitch: 0,
    hp: 100,
    maxHp: 100,
    armor: 50,
    maxArmor: 50,
    grounded: false,
    crouched: false,
    sprinting: false,
    moving: false,
    eyeHeight: 1.62,
    stepTimer: 0,
    hurtTimer: 0,
    alive: true,
    _physInfo: { grounded: false },

    init: function () {
      this.pos = new THREE.Vector3(0, 0, 86);
      this.vel = new THREE.Vector3(0, 0, 0);
    },

    spawn: function (x, y, z, yaw) {
      var up = S.Save.data.progress.upgrades;
      this.maxHp = 100;
      this.maxArmor = 50 + up.armor * 15;
      this.hp = this.maxHp;
      this.armor = this.maxArmor;
      this.pos.set(x, y, z);
      this.vel.set(0, 0, 0);
      this.yaw = yaw || 0;
      this.pitch = 0;
      this.crouched = false;
      this.sprinting = false;
      this.alive = true;
      this.hurtTimer = 0;
      this.eyeHeight = 1.62;
      if (S.Input) S.Input.crouchToggled = false;
    },

    applyRecoil: function (dx, dy) {
      this.yaw += dx;
      this.pitch = Math.max(-MAX_PITCH, Math.min(MAX_PITCH, this.pitch + dy));
    },

    takeDamage: function (amount, srcX, srcZ) {
      if (!this.alive) return;
      var diff = S.Save.data.settings.gameplay.difficulty;
      var mul = diff === "easy" ? 0.65 : (diff === "hard" ? 1.35 : 1.0);
      var dmg = Math.max(1, Math.round(amount * mul));

      if (this.armor > 0) {
        var abs = Math.min(this.armor, Math.ceil(dmg * 0.65));
        this.armor -= abs;
        dmg -= abs;
      }
      this.hp = Math.max(0, this.hp - dmg);
      this.hurtTimer = 4.0;
      S.Audio.playHurt();
      S.Save.vibrate(35);

      if (S.HUD && srcX !== undefined) {
        S.HUD.showDamageArc(this.pos.x, this.pos.z, this.yaw, srcX, srcZ);
      }

      if (this.hp <= 0) {
        this.alive = false;
        if (S.Missions) S.Missions.onPlayerDeath();
      }
    },

    applyAimAssist: function (dt, input) {
      var aa = S.Save.data.settings.controls.aimAssist / 100;
      if (aa <= 0.01 || !S.Enemies) return 1.0;

      var cam = S.Core.camera;
      var fwd = S.Core.v1.set(0, 0, -1).applyQuaternion(cam.quaternion).normalize();
      var bestDot = 0.965; // ~15 deg cone
      var bestEnemy = null;

      var list = S.Enemies.pool;
      for (var i = 0; i < list.length; i++) {
        var e = list[i];
        if (!e.active) continue;
        var dx = e.x - cam.position.x;
        var dy = (e.y + 1.25) - cam.position.y;
        var dz = e.z - cam.position.z;
        var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > 60 || dist < 1.2) continue;
        var dot = (dx * fwd.x + dy * fwd.y + dz * fwd.z) / dist;
        if (dot > bestDot) {
          if (S.Physics.hasLOS(cam.position.x, cam.position.y, cam.position.z, e.x, e.y + 1.25, e.z)) {
            bestDot = dot;
            bestEnemy = e;
          }
        }
      }

      if (!bestEnemy) return 1.0;

      // Gentle ADS magnetism
      if (input.adsActive) {
        var tx = bestEnemy.x - cam.position.x;
        var ty = (bestEnemy.y + 1.3) - cam.position.y;
        var tz = bestEnemy.z - cam.position.z;
        var tYaw = Math.atan2(-tx, -tz);
        var hDist = Math.sqrt(tx * tx + tz * tz);
        var tPitch = Math.atan2(ty, hDist);
        var dYaw = Math.atan2(Math.sin(tYaw - this.yaw), Math.cos(tYaw - this.yaw));
        var dPitch = tPitch - this.pitch;
        var pull = Math.min(1, dt * 4.5 * aa);
        this.yaw += dYaw * pull;
        this.pitch += dPitch * pull;
      }

      // Reticle slowdown inside cone
      return 1.0 - 0.45 * aa;
    },

    checkPickups: function () {
      var list = S.World.pickups;
      for (var i = list.length - 1; i >= 0; i--) {
        var pk = list[i];
        if (!pk.active) continue;
        var dx = pk.x - this.pos.x;
        var dz = pk.z - this.pos.z;
        if (dx * dx + dz * dz < 2.4 && Math.abs(pk.y - this.pos.y) < 1.8) {
          var taken = false;
          if (pk.type === "medkit" && this.hp < this.maxHp) {
            this.hp = Math.min(this.maxHp, this.hp + 45);
            taken = true;
          } else if (pk.type === "armor" && this.armor < this.maxArmor) {
            this.armor = Math.min(this.maxArmor, this.armor + 35);
            taken = true;
          } else if (pk.type === "ammo") {
            var st = S.Weapons.getCurrentState();
            st.res += st.maxMag * 2;
            taken = true;
          } else if (pk.type === "grenade" && S.Weapons.grenades < 5) {
            S.Weapons.grenades = Math.min(5, S.Weapons.grenades + 2);
            taken = true;
          } else if (pk.type === "airdrop") {
            this.hp = this.maxHp;
            this.armor = this.maxArmor;
            S.Weapons.grenades = Math.min(5, S.Weapons.grenades + 2);
            var st2 = S.Weapons.getCurrentState();
            st2.res += st2.maxMag * 3;
            S.Weapons.equipWeaponId(Math.random() > 0.5 ? "sniper" : "shotgun");
            S.HUD.showBanner("AIRDROP COLLECTED: FULL SUPPLY!");
            taken = true;
          }
          if (taken) {
            S.Audio.playPickup();
            if (pk.temporary) {
              S.World.group.remove(pk.mesh);
              list.splice(i, 1);
            } else {
              pk.active = false;
              pk.mesh.visible = false;
              pk.respawnTimer = 25;
            }
          }
        }
      }
    },

    update: function (dt, input) {
      if (!this.alive) return;

      // Look rotation + Aim Assist slowdown
      var slow = this.applyAimAssist(dt, input);
      this.yaw -= input.smoothDX * slow;
      this.pitch = Math.max(-MAX_PITCH, Math.min(MAX_PITCH, this.pitch - input.smoothDY * slow));

      // Movement
      this.crouched = input.crouchToggled;
      var mag = Math.sqrt(input.moveX * input.moveX + input.moveY * input.moveY);
      this.moving = mag > 0.08;
      this.sprinting = !this.crouched && !input.adsActive && (input.sprintLock || (input.moveY > 0.85));

      var upSpd = 1 + S.Save.data.progress.upgrades.speed * 0.06;
      var baseSpeed = this.crouched ? 3.2 : (this.sprinting ? 8.2 : 5.6);
      if (input.adsActive) baseSpeed *= 0.65;
      baseSpeed *= upSpd;

      var sinY = Math.sin(this.yaw), cosY = Math.cos(this.yaw);
      var moveWorldX = (-sinY * input.moveY + cosY * input.moveX) * baseSpeed;
      var moveWorldZ = (-cosY * input.moveY - sinY * input.moveX) * baseSpeed;

      this.vel.x = moveWorldX;
      this.vel.z = moveWorldZ;

      if (input.jumpPressed && this.grounded) {
        this.vel.y = 6.6;
        this.grounded = false;
        this.crouched = false;
        input.crouchToggled = false;
      }

      // Gravity
      this.vel.y -= 18.0 * dt;
      this.pos.x += this.vel.x * dt;
      this.pos.y += this.vel.y * dt;
      this.pos.z += this.vel.z * dt;

      var capH = this.crouched ? 1.2 : 1.8;
      S.Physics.resolveCapsule(this.pos, this.vel, 0.4, capH, 0.35, this._physInfo);
      this.grounded = this._physInfo.grounded;

      // Smooth eye height
      var targetEye = this.crouched ? 1.02 : 1.62;
      this.eyeHeight += (targetEye - this.eyeHeight) * Math.min(1, dt * 12);

      // Update camera transform
      S.Core.camera.position.set(this.pos.x, this.pos.y + this.eyeHeight, this.pos.z);
      S.Core.camera.rotation.set(this.pitch, this.yaw, 0, "YXZ");

      // Footsteps
      if (this.moving && this.grounded) {
        this.stepTimer -= dt;
        if (this.stepTimer <= 0) {
          this.stepTimer = this.sprinting ? 0.30 : 0.44;
          S.Audio.playStep();
        }
      }

      // Slow health regen after 4s out of combat (Easy/Normal)
      if (this.hurtTimer > 0) this.hurtTimer -= dt;
      else if (this.hp < this.maxHp && S.Save.data.settings.gameplay.difficulty !== "hard") {
        this.hp = Math.min(this.maxHp, this.hp + dt * 4.5);
      }

      this.checkPickups();
    }
  };

  S.Player = Player;
})();
