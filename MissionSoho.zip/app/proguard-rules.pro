# Mission Soho ProGuard rules
-keepclassmembers class com.missionsoho.game.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
